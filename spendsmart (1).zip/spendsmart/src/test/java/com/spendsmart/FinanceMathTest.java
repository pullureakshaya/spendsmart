package com.spendsmart;

import com.spendsmart.util.FinanceMath;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class FinanceMathTest {

    @Test
    void percentIsCalculatedCorrectly() {
        assertEquals(80.0, FinanceMath.percent(new BigDecimal("800"), new BigDecimal("1000")));
        assertEquals(0.0, FinanceMath.percent(new BigDecimal("800"), BigDecimal.ZERO));
    }

    @Test
    void alertLevelsFollowThresholds() {
        assertNull(FinanceMath.alertLevel(79.9));
        assertEquals("80", FinanceMath.alertLevel(80));
        assertEquals("FULL", FinanceMath.alertLevel(100));
        assertEquals("OVER", FinanceMath.alertLevel(100.1));
    }

    @Test
    void healthScoreIsBoundedAndSensible() {
        int great = FinanceMath.healthScore(30, true, 60, true);
        int poor = FinanceMath.healthScore(-10, true, 140, false);
        assertEquals(100, great);
        assertTrue(poor < 40);
        assertEquals("Excellent", FinanceMath.healthLabel(great));
        assertEquals("Needs attention", FinanceMath.healthLabel(poor));
    }
}
