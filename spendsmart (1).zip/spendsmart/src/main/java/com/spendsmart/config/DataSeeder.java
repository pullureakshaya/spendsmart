package com.spendsmart.config;

import com.spendsmart.entity.*;
import com.spendsmart.repository.*;
import com.spendsmart.service.NotificationService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Random;

/**
 * Creates a demo account with 4 months of realistic sample data (only when the users table is empty).
 * Login:  demo@spendsmart.com  /  Demo@123
 */
@Component
public class DataSeeder implements CommandLineRunner {
    private final UserRepository users;
    private final ExpenseRepository expenses;
    private final IncomeRepository incomes;
    private final BudgetRepository budgets;
    private final SavingsGoalRepository goals;
    private final RecurringTransactionRepository recurring;
    private final NotificationService notifications;
    private final PasswordEncoder encoder;

    @Value("${spendsmart.seed-demo:true}")
    private boolean seed;

    public DataSeeder(UserRepository users, ExpenseRepository expenses, IncomeRepository incomes, BudgetRepository budgets,
                      SavingsGoalRepository goals, RecurringTransactionRepository recurring,
                      NotificationService notifications, PasswordEncoder encoder) {
        this.users = users;
        this.expenses = expenses;
        this.incomes = incomes;
        this.budgets = budgets;
        this.goals = goals;
        this.recurring = recurring;
        this.notifications = notifications;
        this.encoder = encoder;
    }

    // category, min, max, description
    private static final Object[][] SPEND = {
        {"Food", 120, 650, "Groceries"}, {"Food", 80, 400, "Restaurant"}, {"Food", 60, 250, "Snacks & coffee"},
        {"Shopping", 500, 2200, "Clothes"}, {"Shopping", 300, 1500, "Online order"},
        {"Transportation", 40, 450, "Auto / cab"}, {"Transportation", 500, 1200, "Fuel"},
        {"Education", 400, 1800, "Course / books"},
        {"Entertainment", 150, 700, "Movie / OTT"}, {"Entertainment", 200, 900, "Outing with friends"},
        {"Healthcare", 200, 1200, "Pharmacy"},
        {"Bills", 300, 1100, "Electricity / mobile"},
        {"Others", 100, 600, "Miscellaneous"}
    };
    private static final String[] PAY = {"UPI", "UPI", "Cash", "Debit Card", "Credit Card", "Net Banking"};

    @Override
    public void run(String... args) {
        if (!seed || users.count() > 0) return;

        User u = new User();
        u.setFullName("Demo User");
        u.setEmail("demo@spendsmart.com");
        u.setPassword(encoder.encode("Demo@123"));
        u.setPhone("9876543210");
        users.save(u);

        Random r = new Random(42);
        LocalDate today = LocalDate.now();

        for (int back = 3; back >= 0; back--) {
            YearMonth ym = YearMonth.from(today).minusMonths(back);
            int lastDay = back == 0 ? today.getDayOfMonth() : ym.lengthOfMonth();

            addIncome(u, "Salary", 55000, ym.atDay(1), "Monthly salary");
            if (lastDay >= 15 && r.nextBoolean()) addIncome(u, "Freelance", 3000 + r.nextInt(7000), ym.atDay(15), "Freelance project");
            if (lastDay >= 20) addIncome(u, "Investments", 500 + r.nextInt(1500), ym.atDay(20), "Dividend / interest");

            if (lastDay >= 5) addExpense(u, "Bills", 12000, ym.atDay(5), "House rent", "Net Banking");
            if (lastDay >= 8) addExpense(u, "Bills", 649, ym.atDay(8), "Internet bill", "UPI");

            int count = back == 0 ? Math.max(6, lastDay) : 28;
            for (int i = 0; i < count; i++) {
                Object[] s = SPEND[r.nextInt(SPEND.length)];
                int min = (Integer) s[1], max = (Integer) s[2];
                int amount = min + r.nextInt(max - min);
                addExpense(u, (String) s[0], amount, ym.atDay(1 + r.nextInt(lastDay)), (String) s[3], PAY[r.nextInt(PAY.length)]);
            }
            if (back == 0 && lastDay >= 2) addExpense(u, "Shopping", 2400, ym.atDay(2), "Festival shopping", "Credit Card");
        }

        YearMonth now = YearMonth.from(today);
        Object[][] limits = {{"ALL", 32000}, {"Food", 4000}, {"Shopping", 5000}, {"Transportation", 3000},
                {"Entertainment", 3000}, {"Bills", 15000}, {"Education", 3000}};
        for (int back = 1; back >= 0; back--) {
            YearMonth ym = now.minusMonths(back);
            for (Object[] l : limits) {
                Budget b = new Budget();
                b.setUser(u);
                b.setCategory((String) l[0]);
                b.setLimitAmount(BigDecimal.valueOf((Integer) l[1]));
                b.setMonth(ym.getMonthValue());
                b.setYear(ym.getYear());
                budgets.save(b);
            }
        }
        // creates budget alerts for the current month
        for (Object[] l : limits) notifications.checkBudgets(u, (String) l[0], today);

        addGoal(u, "Emergency fund", 100000, 35000, today.plusMonths(10));
        addGoal(u, "New laptop", 60000, 22000, today.plusMonths(5));
        addGoal(u, "Goa trip", 25000, 25000, today.plusMonths(2));
        notifications.add(u, "SUCCESS", "Goal reached: Goa trip! You saved ₹25,000.", "goal-seed");

        addRecurring(u, "INCOME", 55000, "Salary", "Monthly salary", now.plusMonths(1).atDay(1), "MONTHLY");
        addRecurring(u, "EXPENSE", 12000, "Bills", "House rent", now.plusMonths(1).atDay(5), "MONTHLY");
        addRecurring(u, "EXPENSE", 199, "Entertainment", "Streaming subscription", today.plusDays(6), "MONTHLY");
        addRecurring(u, "EXPENSE", 1500, "Education", "Weekly tuition", today.plusDays(2), "WEEKLY");

        System.out.println(">>> SpendSmart demo data created. Login: demo@spendsmart.com / Demo@123");
    }

    private void addExpense(User u, String cat, int amount, LocalDate date, String desc, String pay) {
        Expense e = new Expense();
        e.setUser(u); e.setCategory(cat); e.setAmount(BigDecimal.valueOf(amount));
        e.setExpenseDate(date); e.setDescription(desc); e.setPaymentMethod(pay);
        expenses.save(e);
    }

    private void addIncome(User u, String cat, int amount, LocalDate date, String desc) {
        Income i = new Income();
        i.setUser(u); i.setCategory(cat); i.setAmount(BigDecimal.valueOf(amount));
        i.setIncomeDate(date); i.setDescription(desc);
        incomes.save(i);
    }

    private void addGoal(User u, String name, int target, int saved, LocalDate deadline) {
        SavingsGoal g = new SavingsGoal();
        g.setUser(u); g.setName(name); g.setTargetAmount(BigDecimal.valueOf(target));
        g.setSavedAmount(BigDecimal.valueOf(saved)); g.setDeadline(deadline);
        goals.save(g);
    }

    private void addRecurring(User u, String type, int amount, String cat, String desc, LocalDate next, String freq) {
        RecurringTransaction t = new RecurringTransaction();
        t.setUser(u); t.setType(type); t.setAmount(BigDecimal.valueOf(amount)); t.setCategory(cat);
        t.setDescription(desc); t.setFrequency(freq); t.setNextDate(next); t.setPaymentMethod("UPI");
        recurring.save(t);
    }
}
