package com.spendsmart.repository;

import com.spendsmart.entity.Expense;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface ExpenseRepository extends JpaRepository<Expense, Long> {
    Optional<Expense> findByIdAndUserId(Long id, Long userId);
    List<Expense> findTop5ByUserIdOrderByExpenseDateDescIdDesc(Long userId);

    /** category "" = all categories, q "" = no text filter */
    @Query("select e from Expense e where e.user.id = :uid and e.expenseDate between :from and :to " +
           "and (:cat = '' or e.category = :cat) " +
           "and lower(coalesce(e.description, '')) like lower(concat('%', :q, '%')) " +
           "order by e.expenseDate desc, e.id desc")
    List<Expense> search(@Param("uid") Long uid, @Param("cat") String cat,
                         @Param("from") LocalDate from, @Param("to") LocalDate to, @Param("q") String q);

    @Query("select sum(e.amount) from Expense e where e.user.id = :uid and e.expenseDate between :from and :to")
    BigDecimal sumBetween(@Param("uid") Long uid, @Param("from") LocalDate from, @Param("to") LocalDate to);

    @Query("select sum(e.amount) from Expense e where e.user.id = :uid and e.category = :cat " +
           "and e.expenseDate between :from and :to")
    BigDecimal sumCategoryBetween(@Param("uid") Long uid, @Param("cat") String cat,
                                  @Param("from") LocalDate from, @Param("to") LocalDate to);

    default BigDecimal total(Long uid, LocalDate from, LocalDate to) {
        BigDecimal v = sumBetween(uid, from, to);
        return v == null ? BigDecimal.ZERO : v;
    }

    default BigDecimal totalByCategory(Long uid, String cat, LocalDate from, LocalDate to) {
        BigDecimal v = sumCategoryBetween(uid, cat, from, to);
        return v == null ? BigDecimal.ZERO : v;
    }

    /** rows: [category, sum] highest first */
    @Query("select e.category, sum(e.amount) from Expense e where e.user.id = :uid " +
           "and e.expenseDate between :from and :to group by e.category order by sum(e.amount) desc")
    List<Object[]> byCategory(@Param("uid") Long uid, @Param("from") LocalDate from, @Param("to") LocalDate to);

    /** rows: [month number 1-12, sum] */
    @Query("select month(e.expenseDate), sum(e.amount) from Expense e where e.user.id = :uid " +
           "and year(e.expenseDate) = :yr group by month(e.expenseDate)")
    List<Object[]> byMonth(@Param("uid") Long uid, @Param("yr") int yr);

    /** rows: [date, sum] */
    @Query("select e.expenseDate, sum(e.amount) from Expense e where e.user.id = :uid " +
           "and e.expenseDate between :from and :to group by e.expenseDate")
    List<Object[]> byDay(@Param("uid") Long uid, @Param("from") LocalDate from, @Param("to") LocalDate to);
}
