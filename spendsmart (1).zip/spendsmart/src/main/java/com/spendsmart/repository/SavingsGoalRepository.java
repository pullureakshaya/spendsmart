package com.spendsmart.repository;

import com.spendsmart.entity.SavingsGoal;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface SavingsGoalRepository extends JpaRepository<SavingsGoal, Long> {
    List<SavingsGoal> findByUserIdOrderByIdDesc(Long userId);
    Optional<SavingsGoal> findByIdAndUserId(Long id, Long userId);
}
