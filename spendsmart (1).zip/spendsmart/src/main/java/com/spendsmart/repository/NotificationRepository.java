package com.spendsmart.repository;

import com.spendsmart.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findTop30ByUserIdOrderByCreatedAtDescIdDesc(Long userId);
    long countByUserIdAndSeenFalse(Long userId);
    boolean existsByUserIdAndAlertKey(Long userId, String alertKey);
    Optional<Notification> findByIdAndUserId(Long id, Long userId);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update Notification n set n.seen = true where n.user.id = :uid and n.seen = false")
    int markAllSeen(@Param("uid") Long uid);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("delete from Notification n where n.user.id = :uid")
    int clearAll(@Param("uid") Long uid);
}
