package com.spendsmart.repository;

import com.spendsmart.entity.Income;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface IncomeRepository extends JpaRepository<Income, Long> {
    Optional<Income> findByIdAndUserId(Long id, Long userId);
    List<Income> findTop5ByUserIdOrderByIncomeDateDescIdDesc(Long userId);

    @Query("select i from Income i where i.user.id = :uid and i.incomeDate between :from and :to " +
           "and (:cat = '' or i.category = :cat) " +
           "and lower(coalesce(i.description, '')) like lower(concat('%', :q, '%')) " +
           "order by i.incomeDate desc, i.id desc")
    List<Income> search(@Param("uid") Long uid, @Param("cat") String cat,
                        @Param("from") LocalDate from, @Param("to") LocalDate to, @Param("q") String q);

    @Query("select sum(i.amount) from Income i where i.user.id = :uid and i.incomeDate between :from and :to")
    BigDecimal sumBetween(@Param("uid") Long uid, @Param("from") LocalDate from, @Param("to") LocalDate to);

    default BigDecimal total(Long uid, LocalDate from, LocalDate to) {
        BigDecimal v = sumBetween(uid, from, to);
        return v == null ? BigDecimal.ZERO : v;
    }

    @Query("select i.category, sum(i.amount) from Income i where i.user.id = :uid " +
           "and i.incomeDate between :from and :to group by i.category order by sum(i.amount) desc")
    List<Object[]> byCategory(@Param("uid") Long uid, @Param("from") LocalDate from, @Param("to") LocalDate to);

    @Query("select month(i.incomeDate), sum(i.amount) from Income i where i.user.id = :uid " +
           "and year(i.incomeDate) = :yr group by month(i.incomeDate)")
    List<Object[]> byMonth(@Param("uid") Long uid, @Param("yr") int yr);
}
