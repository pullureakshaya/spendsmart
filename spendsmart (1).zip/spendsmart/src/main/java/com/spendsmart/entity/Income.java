package com.spendsmart.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "income", indexes = @Index(name = "idx_inc_user_date", columnList = "user_id, incomeDate"))
@Getter @Setter @NoArgsConstructor
public class Income {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id")
    private User user;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be greater than zero")
    @Digits(integer = 10, fraction = 2, message = "Amount can have at most 10 digits and 2 decimals")
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal amount;

    @NotBlank(message = "Income source is required")
    @Pattern(regexp = "Salary|Freelance|Business|Investments|Gift|Others", message = "Invalid income source")
    private String category;

    @NotNull(message = "Date is required")
    private LocalDate incomeDate;

    @Size(max = 255, message = "Description can be at most 255 characters")
    private String description;
}
