package com.spendsmart.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "recurring_transactions")
@Getter @Setter @NoArgsConstructor
public class RecurringTransaction {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id")
    private User user;

    @NotBlank @Pattern(regexp = "EXPENSE|INCOME", message = "Type must be EXPENSE or INCOME")
    private String type;

    @NotNull @DecimalMin(value = "0.01", message = "Amount must be greater than zero")
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal amount;

    @NotBlank(message = "Category is required")
    private String category;

    @Size(max = 255)
    private String description;

    private String paymentMethod = "Cash";

    @NotBlank @Pattern(regexp = "DAILY|WEEKLY|MONTHLY|YEARLY", message = "Invalid frequency")
    private String frequency;

    @NotNull(message = "Next date is required")
    private LocalDate nextDate;

    private boolean active = true;
}
