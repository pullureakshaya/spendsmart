package com.spendsmart.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;

@Entity
@Table(name = "notifications", indexes = @Index(name = "idx_notif_user", columnList = "user_id, seen"))
@Getter @Setter @NoArgsConstructor
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id")
    private User user;

    @Column(nullable = false)
    private String message;

    /** WARNING, DANGER, INFO, SUCCESS */
    @Column(length = 15)
    private String type = "INFO";

    private boolean seen = false;

    /** Prevents duplicate alerts, e.g. "2026-11:Food:80" */
    @JsonIgnore
    private String alertKey;

    private LocalDateTime createdAt = LocalDateTime.now();
}
