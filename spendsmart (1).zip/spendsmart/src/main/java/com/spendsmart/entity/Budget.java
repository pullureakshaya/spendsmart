package com.spendsmart.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;

/** category = "ALL" means the overall monthly budget. */
@Entity
@Table(name = "budgets", uniqueConstraints = @UniqueConstraint(columnNames = {"user_id", "category", "month", "year"}))
@Getter @Setter @NoArgsConstructor
public class Budget {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id")
    private User user;

    @NotBlank(message = "Category is required")
    @Pattern(regexp = "ALL|Food|Shopping|Transportation|Education|Entertainment|Healthcare|Bills|Others",
             message = "Invalid budget category")
    private String category;

    @NotNull(message = "Budget limit is required")
    @DecimalMin(value = "1.00", message = "Budget limit must be at least 1")
    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal limitAmount;

    @Min(1) @Max(12)
    private int month;

    @Min(2000) @Max(2100)
    private int year;
}
