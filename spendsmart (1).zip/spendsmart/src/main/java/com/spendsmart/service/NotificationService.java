package com.spendsmart.service;

import com.spendsmart.entity.Notification;
import com.spendsmart.entity.User;
import com.spendsmart.repository.BudgetRepository;
import com.spendsmart.repository.ExpenseRepository;
import com.spendsmart.repository.NotificationRepository;
import com.spendsmart.util.FinanceMath;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;

@Service
public class NotificationService {
    private final NotificationRepository notifications;
    private final BudgetRepository budgets;
    private final ExpenseRepository expenses;

    public NotificationService(NotificationRepository notifications, BudgetRepository budgets, ExpenseRepository expenses) {
        this.notifications = notifications;
        this.budgets = budgets;
        this.expenses = expenses;
    }

    public void add(User user, String type, String message, String alertKey) {
        if (alertKey != null && notifications.existsByUserIdAndAlertKey(user.getId(), alertKey)) return;
        Notification n = new Notification();
        n.setUser(user);
        n.setType(type);
        n.setMessage(message);
        n.setAlertKey(alertKey);
        notifications.save(n);
    }

    /** Called after an expense or budget changes: checks the category budget and the overall budget. */
    public void checkBudgets(User user, String category, LocalDate date) {
        YearMonth ym = YearMonth.from(date);
        check(user, category, ym);
        check(user, "ALL", ym);
    }

    private void check(User user, String category, YearMonth ym) {
        budgets.findByUserIdAndCategoryAndMonthAndYear(user.getId(), category, ym.getMonthValue(), ym.getYear())
            .ifPresent(b -> {
                LocalDate from = ym.atDay(1), to = ym.atEndOfMonth();
                BigDecimal spent = "ALL".equals(category)
                        ? expenses.total(user.getId(), from, to)
                        : expenses.totalByCategory(user.getId(), category, from, to);
                double pct = FinanceMath.percent(spent, b.getLimitAmount());
                String level = FinanceMath.alertLevel(pct);
                if (level == null) return;

                String label = "ALL".equals(category) ? "monthly budget" : category + " budget";
                String month = ym.getMonth().name().charAt(0) + ym.getMonth().name().substring(1).toLowerCase();
                String msg;
                String type;
                switch (level) {
                    case "OVER" -> {
                        msg = "You have exceeded your " + label + " for " + month + " by ₹"
                                + spent.subtract(b.getLimitAmount()).setScale(0, java.math.RoundingMode.HALF_UP) + ".";
                        type = "DANGER";
                    }
                    case "FULL" -> {
                        msg = "You have used 100% of your " + label + " for " + month + ". Any more spending goes over budget.";
                        type = "DANGER";
                    }
                    default -> {
                        msg = "Heads up: you have used " + Math.round(pct) + "% of your " + label + " for " + month + ".";
                        type = "WARNING";
                    }
                }
                add(user, type, msg, ym + ":" + category + ":" + level);
            });
    }
}
