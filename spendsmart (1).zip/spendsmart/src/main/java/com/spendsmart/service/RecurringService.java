package com.spendsmart.service;

import com.spendsmart.entity.Expense;
import com.spendsmart.entity.Income;
import com.spendsmart.entity.RecurringTransaction;
import com.spendsmart.repository.ExpenseRepository;
import com.spendsmart.repository.IncomeRepository;
import com.spendsmart.repository.RecurringTransactionRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;

/** Automatically posts bills / salary / subscriptions on their due date. */
@Service
public class RecurringService {
    private final RecurringTransactionRepository recurring;
    private final ExpenseRepository expenses;
    private final IncomeRepository incomes;
    private final NotificationService notificationService;

    public RecurringService(RecurringTransactionRepository recurring, ExpenseRepository expenses,
                            IncomeRepository incomes, NotificationService notificationService) {
        this.recurring = recurring;
        this.expenses = expenses;
        this.incomes = incomes;
        this.notificationService = notificationService;
    }

    /** Runs every day at 00:05 server time. */
    @Scheduled(cron = "0 5 0 * * *")
    @Transactional
    public int processDue() {
        LocalDate today = LocalDate.now();
        List<RecurringTransaction> due = recurring.findByActiveTrueAndNextDateLessThanEqual(today);
        int created = 0;
        for (RecurringTransaction r : due) {
            while (!r.getNextDate().isAfter(today)) {
                post(r, r.getNextDate());
                r.setNextDate(advance(r.getNextDate(), r.getFrequency()));
                created++;
            }
            recurring.save(r);
        }
        return created;
    }

    /** Same as processDue() but only for one user (used by the "Run now" button). */
    @Transactional
    public int processForUser(Long userId) {
        LocalDate today = LocalDate.now();
        int created = 0;
        for (RecurringTransaction r : recurring.findByUserIdOrderByNextDateAsc(userId)) {
            if (!r.isActive()) continue;
            while (!r.getNextDate().isAfter(today)) {
                post(r, r.getNextDate());
                r.setNextDate(advance(r.getNextDate(), r.getFrequency()));
                created++;
            }
            recurring.save(r);
        }
        return created;
    }

    private void post(RecurringTransaction r, LocalDate date) {
        String desc = (r.getDescription() == null || r.getDescription().isBlank() ? r.getCategory() : r.getDescription()) + " (auto)";
        if ("INCOME".equals(r.getType())) {
            Income i = new Income();
            i.setUser(r.getUser());
            i.setAmount(r.getAmount());
            i.setCategory(r.getCategory());
            i.setIncomeDate(date);
            i.setDescription(desc);
            incomes.save(i);
        } else {
            Expense e = new Expense();
            e.setUser(r.getUser());
            e.setAmount(r.getAmount());
            e.setCategory(r.getCategory());
            e.setExpenseDate(date);
            e.setDescription(desc);
            e.setPaymentMethod(r.getPaymentMethod() == null ? "Cash" : r.getPaymentMethod());
            expenses.save(e);
            notificationService.checkBudgets(r.getUser(), e.getCategory(), date);
        }
        notificationService.add(r.getUser(), "INFO", "Recurring " + r.getType().toLowerCase() + " posted: " + desc
                + " – ₹" + r.getAmount().setScale(0, java.math.RoundingMode.HALF_UP), null);
    }

    public static LocalDate advance(LocalDate d, String frequency) {
        return switch (frequency) {
            case "DAILY" -> d.plusDays(1);
            case "WEEKLY" -> d.plusWeeks(1);
            case "YEARLY" -> d.plusYears(1);
            default -> d.plusMonths(1);
        };
    }
}
