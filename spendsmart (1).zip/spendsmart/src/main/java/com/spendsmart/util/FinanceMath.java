package com.spendsmart.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Pure calculation helpers (easy to unit-test). */
public final class FinanceMath {
    private FinanceMath() {}

    public static double percent(BigDecimal part, BigDecimal whole) {
        if (whole == null || whole.signum() <= 0 || part == null) return 0;
        return part.multiply(BigDecimal.valueOf(100)).divide(whole, 1, RoundingMode.HALF_UP).doubleValue();
    }

    /** Budget alert level: null, "80", "FULL" (=100%) or "OVER" (>100%). */
    public static String alertLevel(double pct) {
        if (pct > 100) return "OVER";
        if (pct >= 100) return "FULL";
        if (pct >= 80) return "80";
        return null;
    }

    /**
     * Financial Health Score (0-100)
     *  - up to 40 points: savings rate (20% of income saved = full marks)
     *  - up to 40 points: budget discipline (<=80% used = full marks)
     *  - up to 20 points: progress on savings goals
     */
    public static int healthScore(double savingsRatePct, boolean hasBudget, double budgetUsedPct, boolean hasGoalProgress) {
        double savingsPart = Math.min(40, Math.max(0, savingsRatePct) * 2);
        double budgetPart;
        if (!hasBudget) budgetPart = 20;
        else if (budgetUsedPct <= 80) budgetPart = 40;
        else if (budgetUsedPct <= 100) budgetPart = 25;
        else budgetPart = 5;
        double goalPart = hasGoalProgress ? 20 : 10;
        return (int) Math.round(Math.min(100, savingsPart + budgetPart + goalPart));
    }

    public static String healthLabel(int score) {
        if (score >= 80) return "Excellent";
        if (score >= 60) return "Good";
        if (score >= 40) return "Fair";
        return "Needs attention";
    }
}
