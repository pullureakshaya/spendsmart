package com.spendsmart.controller;

import com.spendsmart.repository.ExpenseRepository;
import com.spendsmart.repository.IncomeRepository;
import com.spendsmart.security.CurrentUser;
import com.spendsmart.util.FinanceMath;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;

@RestController
@RequestMapping("/api/analytics")
public class AnalyticsController {
    private final ExpenseRepository expenses;
    private final IncomeRepository incomes;
    private final CurrentUser currentUser;

    public AnalyticsController(ExpenseRepository expenses, IncomeRepository incomes, CurrentUser currentUser) {
        this.expenses = expenses;
        this.incomes = incomes;
        this.currentUser = currentUser;
    }

    /** month = 0 means the whole year. */
    private LocalDate[] range(int year, int month) {
        if (month == 0) return new LocalDate[]{LocalDate.of(year, 1, 1), LocalDate.of(year, 12, 31)};
        YearMonth ym = YearMonth.of(year, month);
        return new LocalDate[]{ym.atDay(1), ym.atEndOfMonth()};
    }

    private static LocalDate toLocalDate(Object o) {
        if (o instanceof LocalDate d) return d;
        return ((Date) o).toLocalDate();
    }

    /** Totals + category breakdown for the monthly or yearly report. */
    @GetMapping("/report")
    public Map<String, Object> report(@RequestParam int year, @RequestParam(defaultValue = "0") int month) {
        Long uid = currentUser.get().getId();
        LocalDate[] r = range(year, month);
        BigDecimal income = incomes.total(uid, r[0], r[1]);
        BigDecimal expense = expenses.total(uid, r[0], r[1]);
        List<Map<String, Object>> cats = new ArrayList<>();
        for (Object[] row : expenses.byCategory(uid, r[0], r[1])) {
            BigDecimal amt = (BigDecimal) row[1];
            cats.add(Map.of("category", row[0], "total", amt, "percent", FinanceMath.percent(amt, expense)));
        }
        List<Map<String, Object>> sources = new ArrayList<>();
        for (Object[] row : incomes.byCategory(uid, r[0], r[1])) {
            BigDecimal amt = (BigDecimal) row[1];
            sources.add(Map.of("category", row[0], "total", amt, "percent", FinanceMath.percent(amt, income)));
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("income", income);
        out.put("expense", expense);
        out.put("savings", income.subtract(expense));
        out.put("savingsRate", FinanceMath.percent(income.subtract(expense), income));
        out.put("categories", cats);
        out.put("incomeSources", sources);
        return out;
    }

    /** 12 values of income and expense for the bar chart. */
    @GetMapping("/monthly")
    public Map<String, Object> monthly(@RequestParam int year) {
        Long uid = currentUser.get().getId();
        double[] inc = new double[12], exp = new double[12];
        for (Object[] row : incomes.byMonth(uid, year)) inc[((Number) row[0]).intValue() - 1] = ((BigDecimal) row[1]).doubleValue();
        for (Object[] row : expenses.byMonth(uid, year)) exp[((Number) row[0]).intValue() - 1] = ((BigDecimal) row[1]).doubleValue();
        return Map.of("labels", List.of("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"),
                "income", inc, "expense", exp);
    }

    /** Spending trend: per day for a month, per month for a whole year. */
    @GetMapping("/trend")
    public Map<String, Object> trend(@RequestParam int year, @RequestParam(defaultValue = "0") int month) {
        Long uid = currentUser.get().getId();
        List<String> labels = new ArrayList<>();
        List<Double> values = new ArrayList<>();
        if (month == 0) {
            double[] exp = new double[12];
            for (Object[] row : expenses.byMonth(uid, year)) exp[((Number) row[0]).intValue() - 1] = ((BigDecimal) row[1]).doubleValue();
            String[] names = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
            for (int i = 0; i < 12; i++) { labels.add(names[i]); values.add(exp[i]); }
        } else {
            YearMonth ym = YearMonth.of(year, month);
            Map<Integer, Double> byDay = new HashMap<>();
            for (Object[] row : expenses.byDay(uid, ym.atDay(1), ym.atEndOfMonth()))
                byDay.put(toLocalDate(row[0]).getDayOfMonth(), ((BigDecimal) row[1]).doubleValue());
            for (int d = 1; d <= ym.lengthOfMonth(); d++) { labels.add(String.valueOf(d)); values.add(byDay.getOrDefault(d, 0.0)); }
        }
        return Map.of("labels", labels, "values", values);
    }
}
