package com.spendsmart.controller;

import com.spendsmart.entity.Notification;
import com.spendsmart.repository.NotificationRepository;
import com.spendsmart.security.CurrentUser;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {
    private final NotificationRepository repo;
    private final CurrentUser currentUser;

    public NotificationController(NotificationRepository repo, CurrentUser currentUser) {
        this.repo = repo;
        this.currentUser = currentUser;
    }

    @GetMapping
    public Map<String, Object> list() {
        Long uid = currentUser.get().getId();
        List<Notification> items = repo.findTop30ByUserIdOrderByCreatedAtDescIdDesc(uid);
        return Map.of("unread", repo.countByUserIdAndSeenFalse(uid), "items", items);
    }

    @PutMapping("/read-all")
    public Map<String, Object> readAll() {
        return Map.of("updated", repo.markAllSeen(currentUser.get().getId()));
    }

    @PutMapping("/{id}/read")
    public Map<String, String> read(@PathVariable Long id) {
        Notification n = repo.findByIdAndUserId(id, currentUser.get().getId()).orElseThrow(NoSuchElementException::new);
        n.setSeen(true);
        repo.save(n);
        return Map.of("message", "Marked as read");
    }

    @DeleteMapping
    public Map<String, Object> clear() {
        return Map.of("deleted", repo.clearAll(currentUser.get().getId()));
    }
}
