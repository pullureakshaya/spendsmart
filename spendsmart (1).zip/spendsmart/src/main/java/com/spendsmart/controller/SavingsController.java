package com.spendsmart.controller;

import com.spendsmart.entity.SavingsGoal;
import com.spendsmart.entity.User;
import com.spendsmart.repository.SavingsGoalRepository;
import com.spendsmart.security.CurrentUser;
import com.spendsmart.service.NotificationService;
import com.spendsmart.util.FinanceMath;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

@RestController
@RequestMapping("/api/savings")
public class SavingsController {
    private final SavingsGoalRepository repo;
    private final CurrentUser currentUser;
    private final NotificationService notifications;

    public SavingsController(SavingsGoalRepository repo, CurrentUser currentUser, NotificationService notifications) {
        this.repo = repo;
        this.currentUser = currentUser;
        this.notifications = notifications;
    }

    public record ContributionRequest(BigDecimal amount) {}

    private Map<String, Object> view(SavingsGoal g) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", g.getId());
        m.put("name", g.getName());
        m.put("targetAmount", g.getTargetAmount());
        m.put("savedAmount", g.getSavedAmount());
        m.put("deadline", g.getDeadline());
        m.put("percent", Math.min(100, FinanceMath.percent(g.getSavedAmount(), g.getTargetAmount())));
        BigDecimal remaining = g.getTargetAmount().subtract(g.getSavedAmount()).max(BigDecimal.ZERO);
        m.put("remaining", remaining);
        // Advanced: how much to save per month to hit the deadline
        if (g.getDeadline() != null && remaining.signum() > 0) {
            long months = Math.max(1, ChronoUnit.MONTHS.between(LocalDate.now(), g.getDeadline()));
            m.put("monthlyNeeded", remaining.divide(BigDecimal.valueOf(months), 0, java.math.RoundingMode.CEILING));
            m.put("overdue", g.getDeadline().isBefore(LocalDate.now()));
        }
        return m;
    }

    @GetMapping
    public List<Map<String, Object>> list() {
        return repo.findByUserIdOrderByIdDesc(currentUser.get().getId()).stream().map(this::view).toList();
    }

    @PostMapping
    public Map<String, Object> create(@Valid @RequestBody SavingsGoal body) {
        body.setId(null);
        body.setUser(currentUser.get());
        body.setSavedAmount(body.getSavedAmount() == null || body.getSavedAmount().signum() < 0 ? BigDecimal.ZERO : body.getSavedAmount());
        return view(repo.save(body));
    }

    @PutMapping("/{id}")
    public Map<String, Object> update(@PathVariable Long id, @Valid @RequestBody SavingsGoal body) {
        SavingsGoal g = repo.findByIdAndUserId(id, currentUser.get().getId()).orElseThrow(NoSuchElementException::new);
        g.setName(body.getName());
        g.setTargetAmount(body.getTargetAmount());
        g.setDeadline(body.getDeadline());
        return view(repo.save(g));
    }

    /** Positive amount = add money, negative amount = withdraw. */
    @PostMapping("/{id}/contribute")
    public Map<String, Object> contribute(@PathVariable Long id, @RequestBody ContributionRequest req) {
        User user = currentUser.get();
        SavingsGoal g = repo.findByIdAndUserId(id, user.getId()).orElseThrow(NoSuchElementException::new);
        if (req.amount() == null || req.amount().signum() == 0) throw new IllegalArgumentException("Enter an amount other than zero");
        BigDecimal updated = g.getSavedAmount().add(req.amount());
        if (updated.signum() < 0) throw new IllegalArgumentException("You cannot withdraw more than the saved amount");
        boolean wasDone = g.getSavedAmount().compareTo(g.getTargetAmount()) >= 0;
        g.setSavedAmount(updated);
        repo.save(g);
        if (!wasDone && updated.compareTo(g.getTargetAmount()) >= 0) {
            notifications.add(user, "SUCCESS", "Goal reached: " + g.getName() + "! You saved ₹" + updated.setScale(0, java.math.RoundingMode.HALF_UP) + ".", "goal-done:" + g.getId());
        }
        return view(g);
    }

    @DeleteMapping("/{id}")
    public Map<String, String> delete(@PathVariable Long id) {
        SavingsGoal g = repo.findByIdAndUserId(id, currentUser.get().getId()).orElseThrow(NoSuchElementException::new);
        repo.delete(g);
        return Map.of("message", "Goal deleted");
    }
}
