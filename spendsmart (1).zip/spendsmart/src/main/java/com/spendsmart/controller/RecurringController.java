package com.spendsmart.controller;

import com.spendsmart.entity.RecurringTransaction;
import com.spendsmart.repository.RecurringTransactionRepository;
import com.spendsmart.security.CurrentUser;
import com.spendsmart.service.RecurringService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/recurring")
public class RecurringController {
    private final RecurringTransactionRepository repo;
    private final CurrentUser currentUser;
    private final RecurringService service;

    public RecurringController(RecurringTransactionRepository repo, CurrentUser currentUser, RecurringService service) {
        this.repo = repo;
        this.currentUser = currentUser;
        this.service = service;
    }

    private void checkCategory(RecurringTransaction r) {
        String expense = "Food|Shopping|Transportation|Education|Entertainment|Healthcare|Bills|Others";
        String income = "Salary|Freelance|Business|Investments|Gift|Others";
        String allowed = "EXPENSE".equals(r.getType()) ? expense : income;
        if (!r.getCategory().matches(allowed)) throw new IllegalArgumentException("Invalid category for a " + r.getType().toLowerCase());
    }

    @GetMapping
    public List<RecurringTransaction> list() {
        return repo.findByUserIdOrderByNextDateAsc(currentUser.get().getId());
    }

    @PostMapping
    public RecurringTransaction create(@Valid @RequestBody RecurringTransaction body) {
        checkCategory(body);
        body.setId(null);
        body.setUser(currentUser.get());
        return repo.save(body);
    }

    @PutMapping("/{id}")
    public RecurringTransaction update(@PathVariable Long id, @Valid @RequestBody RecurringTransaction body) {
        checkCategory(body);
        RecurringTransaction r = repo.findByIdAndUserId(id, currentUser.get().getId()).orElseThrow(NoSuchElementException::new);
        r.setType(body.getType());
        r.setAmount(body.getAmount());
        r.setCategory(body.getCategory());
        r.setDescription(body.getDescription());
        r.setPaymentMethod(body.getPaymentMethod());
        r.setFrequency(body.getFrequency());
        r.setNextDate(body.getNextDate());
        r.setActive(body.isActive());
        return repo.save(r);
    }

    @DeleteMapping("/{id}")
    public Map<String, String> delete(@PathVariable Long id) {
        RecurringTransaction r = repo.findByIdAndUserId(id, currentUser.get().getId()).orElseThrow(NoSuchElementException::new);
        repo.delete(r);
        return Map.of("message", "Recurring rule deleted");
    }

    /** Post everything that is due today or earlier (the scheduler also does this every night). */
    @PostMapping("/run-now")
    public Map<String, Object> runNow() {
        int n = service.processForUser(currentUser.get().getId());
        return Map.of("created", n, "message", n + " transaction(s) posted");
    }
}
