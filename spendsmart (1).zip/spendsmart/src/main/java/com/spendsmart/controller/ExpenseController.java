package com.spendsmart.controller;

import com.spendsmart.entity.Expense;
import com.spendsmart.entity.User;
import com.spendsmart.repository.ExpenseRepository;
import com.spendsmart.security.CurrentUser;
import com.spendsmart.service.NotificationService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/expenses")
public class ExpenseController {
    private final ExpenseRepository repo;
    private final CurrentUser currentUser;
    private final NotificationService notifications;

    public ExpenseController(ExpenseRepository repo, CurrentUser currentUser, NotificationService notifications) {
        this.repo = repo;
        this.currentUser = currentUser;
        this.notifications = notifications;
    }

    @GetMapping
    public List<Expense> list(@RequestParam(defaultValue = "") String category,
                              @RequestParam(defaultValue = "") String q,
                              @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
                              @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        return repo.search(currentUser.get().getId(), category.trim(),
                from == null ? LocalDate.of(1900, 1, 1) : from,
                to == null ? LocalDate.of(2999, 12, 31) : to, q.trim());
    }

    @PostMapping
    public Expense create(@Valid @RequestBody Expense body) {
        User user = currentUser.get();
        body.setId(null);
        body.setUser(user);
        Expense saved = repo.save(body);
        notifications.checkBudgets(user, saved.getCategory(), saved.getExpenseDate());
        return saved;
    }

    @PutMapping("/{id}")
    public Expense update(@PathVariable Long id, @Valid @RequestBody Expense body) {
        User user = currentUser.get();
        Expense e = repo.findByIdAndUserId(id, user.getId()).orElseThrow(NoSuchElementException::new);
        e.setAmount(body.getAmount());
        e.setCategory(body.getCategory());
        e.setExpenseDate(body.getExpenseDate());
        e.setDescription(body.getDescription());
        e.setPaymentMethod(body.getPaymentMethod());
        Expense saved = repo.save(e);
        notifications.checkBudgets(user, saved.getCategory(), saved.getExpenseDate());
        return saved;
    }

    @DeleteMapping("/{id}")
    public Map<String, String> delete(@PathVariable Long id) {
        Expense e = repo.findByIdAndUserId(id, currentUser.get().getId()).orElseThrow(NoSuchElementException::new);
        repo.delete(e);
        return Map.of("message", "Expense deleted");
    }
}
