package com.spendsmart.controller;

import com.spendsmart.entity.Budget;
import com.spendsmart.entity.Expense;
import com.spendsmart.entity.Income;
import com.spendsmart.entity.SavingsGoal;
import com.spendsmart.entity.User;
import com.spendsmart.repository.*;
import com.spendsmart.security.CurrentUser;
import com.spendsmart.util.FinanceMath;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {
    private final ExpenseRepository expenses;
    private final IncomeRepository incomes;
    private final BudgetRepository budgets;
    private final SavingsGoalRepository goals;
    private final NotificationRepository notifications;
    private final CurrentUser currentUser;

    public DashboardController(ExpenseRepository expenses, IncomeRepository incomes, BudgetRepository budgets,
                               SavingsGoalRepository goals, NotificationRepository notifications, CurrentUser currentUser) {
        this.expenses = expenses;
        this.incomes = incomes;
        this.budgets = budgets;
        this.goals = goals;
        this.notifications = notifications;
        this.currentUser = currentUser;
    }

    private static String inr(BigDecimal v) {
        return "₹" + String.format(Locale.US, "%,.0f", v.setScale(0, RoundingMode.HALF_UP));
    }

    private static Map<String, Object> tip(String type, String text) {
        return Map.of("type", type, "text", text);
    }

    @GetMapping
    public Map<String, Object> dashboard(@RequestParam int year, @RequestParam int month) {
        User user = currentUser.get();
        Long uid = user.getId();
        YearMonth ym = YearMonth.of(year, month);
        LocalDate from = ym.atDay(1), to = ym.atEndOfMonth();

        BigDecimal income = incomes.total(uid, from, to);
        BigDecimal expense = expenses.total(uid, from, to);
        BigDecimal balance = income.subtract(expense);

        // Budget: overall budget if set, otherwise the sum of category budgets
        List<Budget> monthBudgets = budgets.findByUserIdAndMonthAndYear(uid, month, year);
        BigDecimal budget = BigDecimal.ZERO;
        BigDecimal categoryBudgetSum = BigDecimal.ZERO;
        for (Budget b : monthBudgets) {
            if ("ALL".equals(b.getCategory())) budget = b.getLimitAmount();
            else categoryBudgetSum = categoryBudgetSum.add(b.getLimitAmount());
        }
        if (budget.signum() == 0) budget = categoryBudgetSum;
        double budgetPct = FinanceMath.percent(expense, budget);
        double savingsRate = FinanceMath.percent(balance, income);

        // Category breakdown
        List<Map<String, Object>> cats = new ArrayList<>();
        String topCategory = null;
        BigDecimal topAmount = BigDecimal.ZERO;
        for (Object[] row : expenses.byCategory(uid, from, to)) {
            BigDecimal amt = (BigDecimal) row[1];
            cats.add(Map.of("category", row[0], "total", amt));
            if (topCategory == null) { topCategory = (String) row[0]; topAmount = amt; }
        }

        // Recent transactions (expenses + income merged)
        List<Map<String, Object>> recent = new ArrayList<>();
        for (Expense e : expenses.findTop5ByUserIdOrderByExpenseDateDescIdDesc(uid)) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("type", "EXPENSE"); m.put("title", e.getDescription() == null || e.getDescription().isBlank() ? e.getCategory() : e.getDescription());
            m.put("category", e.getCategory()); m.put("amount", e.getAmount()); m.put("date", e.getExpenseDate().toString());
            recent.add(m);
        }
        for (Income i : incomes.findTop5ByUserIdOrderByIncomeDateDescIdDesc(uid)) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("type", "INCOME"); m.put("title", i.getDescription() == null || i.getDescription().isBlank() ? i.getCategory() : i.getDescription());
            m.put("category", i.getCategory()); m.put("amount", i.getAmount()); m.put("date", i.getIncomeDate().toString());
            recent.add(m);
        }
        recent.sort((a, b) -> ((String) b.get("date")).compareTo((String) a.get("date")));
        if (recent.size() > 6) recent = new ArrayList<>(recent.subList(0, 6));

        // Goals
        List<SavingsGoal> goalList = goals.findByUserIdOrderByIdDesc(uid);
        BigDecimal totalSaved = goalList.stream().map(SavingsGoal::getSavedAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        boolean goalProgress = totalSaved.signum() > 0;

        // ---- Smart insights ----
        List<Map<String, Object>> insights = new ArrayList<>();
        LocalDate today = LocalDate.now();
        boolean currentMonth = YearMonth.from(today).equals(ym);

        if (topCategory != null && expense.signum() > 0) {
            insights.add(tip("info", topCategory + " is your biggest expense: " + inr(topAmount) + " ("
                    + Math.round(FinanceMath.percent(topAmount, expense)) + "% of spending)."));
        }
        YearMonth prev = ym.minusMonths(1);
        BigDecimal prevExpense = expenses.total(uid, prev.atDay(1), prev.atEndOfMonth());
        if (prevExpense.signum() > 0 && expense.signum() > 0) {
            double change = expense.subtract(prevExpense).multiply(BigDecimal.valueOf(100)).divide(prevExpense, 0, RoundingMode.HALF_UP).doubleValue();
            if (!currentMonth || today.getDayOfMonth() > 7) {
                if (currentMonth) {
                    // compare same day-range of last month for fairness
                    BigDecimal prevSoFar = expenses.total(uid, prev.atDay(1), prev.atDay(Math.min(today.getDayOfMonth(), prev.lengthOfMonth())));
                    if (prevSoFar.signum() > 0) {
                        change = expense.subtract(prevSoFar).multiply(BigDecimal.valueOf(100)).divide(prevSoFar, 0, RoundingMode.HALF_UP).doubleValue();
                    }
                }
                String dir = change >= 0 ? "up" : "down";
                insights.add(tip(change > 15 ? "warn" : "good", "Spending is " + dir + " " + Math.abs(Math.round(change))
                        + "% compared with " + (currentMonth ? "the same days last month." : "last month.")));
            }
        }
        if (currentMonth && expense.signum() > 0) {
            int day = today.getDayOfMonth();
            int daysInMonth = ym.lengthOfMonth();
            BigDecimal projected = expense.divide(BigDecimal.valueOf(day), 2, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(daysInMonth));
            if (budget.signum() > 0 && projected.compareTo(budget) > 0) {
                insights.add(tip("warn", "At this pace you will spend about " + inr(projected) + " by month end, which is "
                        + inr(projected.subtract(budget)) + " over your budget."));
            } else {
                insights.add(tip("info", "Forecast: about " + inr(projected) + " of spending by month end at your current pace."));
            }
            if (budget.signum() > 0 && budget.compareTo(expense) > 0) {
                int daysLeft = daysInMonth - day + 1;
                insights.add(tip("good", "You can spend about " + inr(budget.subtract(expense).divide(BigDecimal.valueOf(daysLeft), 0, RoundingMode.DOWN))
                        + " per day for the rest of the month and stay within budget."));
            }
        }
        if (income.signum() > 0) {
            insights.add(tip(savingsRate >= 20 ? "good" : savingsRate >= 0 ? "info" : "warn",
                    savingsRate >= 0 ? "You saved " + Math.round(savingsRate) + "% of your income this month."
                                     : "You spent more than you earned this month."));
        }
        if (monthBudgets.isEmpty()) {
            insights.add(tip("info", "Set a monthly budget to get overspending alerts."));
        }

        int score = FinanceMath.healthScore(savingsRate, budget.signum() > 0, budgetPct, goalProgress);

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("income", income);
        out.put("expense", expense);
        out.put("balance", balance);
        out.put("budget", budget);
        out.put("budgetPercent", budgetPct);
        out.put("budgetRemaining", budget.subtract(expense));
        out.put("savings", balance);
        out.put("savingsRate", savingsRate);
        out.put("totalGoalSavings", totalSaved);
        out.put("categories", cats);
        out.put("recent", recent);
        out.put("insights", insights);
        out.put("healthScore", score);
        out.put("healthLabel", FinanceMath.healthLabel(score));
        out.put("unreadNotifications", notifications.countByUserIdAndSeenFalse(uid));
        return out;
    }
}
