package com.spendsmart.controller;

import com.spendsmart.entity.User;
import com.spendsmart.repository.UserRepository;
import com.spendsmart.security.CurrentUser;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {
    private final CurrentUser currentUser;
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final SecurityContextRepository contextRepo;

    public ProfileController(CurrentUser currentUser, UserRepository users, PasswordEncoder encoder, SecurityContextRepository contextRepo) {
        this.currentUser = currentUser;
        this.users = users;
        this.encoder = encoder;
        this.contextRepo = contextRepo;
    }

    public record ProfileRequest(@NotBlank(message = "Name is required") @Size(max = 100) String fullName,
                                 @NotBlank(message = "Email is required") @Email(message = "Enter a valid email address") String email,
                                 @Size(max = 20, message = "Phone can be at most 20 characters") String phone,
                                 @Pattern(regexp = "INR|USD|EUR|GBP", message = "Unsupported currency") String currency) {}

    public record PasswordRequest(@NotBlank(message = "Current password is required") String currentPassword,
                                  @NotBlank(message = "New password is required")
                                  @Size(min = 8, message = "New password must be at least 8 characters")
                                  @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d).+$", message = "Password must contain letters and numbers") String newPassword) {}

    @GetMapping
    public Map<String, Object> get() {
        User u = currentUser.get();
        Map<String, Object> m = new HashMap<>();
        m.put("fullName", u.getFullName());
        m.put("email", u.getEmail());
        m.put("phone", u.getPhone() == null ? "" : u.getPhone());
        m.put("currency", u.getCurrency() == null ? "INR" : u.getCurrency());
        m.put("memberSince", u.getCreatedAt().toLocalDate().toString());
        return m;
    }

    @PutMapping
    public Map<String, String> update(@Valid @RequestBody ProfileRequest req, HttpServletRequest request, HttpServletResponse response) {
        User u = currentUser.get();
        String email = req.email().trim().toLowerCase();
        boolean emailChanged = !email.equals(u.getEmail());
        if (emailChanged && users.existsByEmail(email)) {
            throw new IllegalArgumentException("That email is already used by another account");
        }
        u.setFullName(req.fullName().trim());
        u.setEmail(email);
        u.setPhone(req.phone());
        if (req.currency() != null) u.setCurrency(req.currency());
        users.save(u);

        if (emailChanged) { // keep the session valid under the new email
            UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
                    email, null, SecurityContextHolder.getContext().getAuthentication().getAuthorities());
            SecurityContext ctx = SecurityContextHolder.createEmptyContext();
            ctx.setAuthentication(token);
            SecurityContextHolder.setContext(ctx);
            contextRepo.saveContext(ctx, request, response);
        }
        return Map.of("message", "Profile updated");
    }

    @PutMapping("/password")
    public Map<String, String> changePassword(@Valid @RequestBody PasswordRequest req) {
        User u = currentUser.get();
        if (!encoder.matches(req.currentPassword(), u.getPassword())) {
            throw new IllegalArgumentException("Current password is incorrect");
        }
        u.setPassword(encoder.encode(req.newPassword()));
        users.save(u);
        return Map.of("message", "Password changed");
    }
}
