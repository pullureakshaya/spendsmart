package com.spendsmart.controller;

import com.spendsmart.entity.Expense;
import com.spendsmart.entity.Income;
import com.spendsmart.repository.ExpenseRepository;
import com.spendsmart.repository.IncomeRepository;
import com.spendsmart.security.CurrentUser;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;

/** Advanced: download transactions as a CSV file (opens in Excel). */
@RestController
@RequestMapping("/api/export")
public class ExportController {
    private final ExpenseRepository expenses;
    private final IncomeRepository incomes;
    private final CurrentUser currentUser;

    public ExportController(ExpenseRepository expenses, IncomeRepository incomes, CurrentUser currentUser) {
        this.expenses = expenses;
        this.incomes = incomes;
        this.currentUser = currentUser;
    }

    private static String csv(String s) {
        if (s == null) return "";
        String v = s.replace("\"", "\"\"");
        // guard against spreadsheet formula injection
        if (!v.isEmpty() && "=+-@".indexOf(v.charAt(0)) >= 0) v = "'" + v;
        return "\"" + v + "\"";
    }

    @GetMapping("/transactions.csv")
    public ResponseEntity<byte[]> export(@RequestParam(defaultValue = "expense") String type,
                                         @RequestParam(defaultValue = "") String category,
                                         @RequestParam(defaultValue = "") String q,
                                         @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
                                         @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        Long uid = currentUser.get().getId();
        LocalDate f = from == null ? LocalDate.of(1900, 1, 1) : from;
        LocalDate t = to == null ? LocalDate.of(2999, 12, 31) : to;
        StringBuilder sb = new StringBuilder("\uFEFF");
        if ("income".equalsIgnoreCase(type)) {
            sb.append("Date,Source,Amount,Description\n");
            for (Income i : incomes.search(uid, category.trim(), f, t, q.trim()))
                sb.append(i.getIncomeDate()).append(',').append(csv(i.getCategory())).append(',')
                  .append(i.getAmount()).append(',').append(csv(i.getDescription())).append('\n');
        } else {
            sb.append("Date,Category,Amount,Payment Method,Description\n");
            for (Expense e : expenses.search(uid, category.trim(), f, t, q.trim()))
                sb.append(e.getExpenseDate()).append(',').append(csv(e.getCategory())).append(',')
                  .append(e.getAmount()).append(',').append(csv(e.getPaymentMethod())).append(',')
                  .append(csv(e.getDescription())).append('\n');
        }
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"spendsmart-" + type.toLowerCase() + "s.csv\"")
                .contentType(new MediaType("text", "csv", StandardCharsets.UTF_8))
                .body(sb.toString().getBytes(StandardCharsets.UTF_8));
    }
}
