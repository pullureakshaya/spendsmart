package com.spendsmart.controller;

import com.spendsmart.entity.Budget;
import com.spendsmart.entity.User;
import com.spendsmart.repository.BudgetRepository;
import com.spendsmart.repository.ExpenseRepository;
import com.spendsmart.security.CurrentUser;
import com.spendsmart.service.NotificationService;
import com.spendsmart.util.FinanceMath;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;

@RestController
@RequestMapping("/api/budgets")
public class BudgetController {
    private final BudgetRepository repo;
    private final ExpenseRepository expenses;
    private final CurrentUser currentUser;
    private final NotificationService notifications;

    public BudgetController(BudgetRepository repo, ExpenseRepository expenses, CurrentUser currentUser, NotificationService notifications) {
        this.repo = repo;
        this.expenses = expenses;
        this.currentUser = currentUser;
        this.notifications = notifications;
    }

    /** Budgets of one month, each with spent / remaining / percent used. */
    @GetMapping
    public List<Map<String, Object>> list(@RequestParam int month, @RequestParam int year) {
        User user = currentUser.get();
        YearMonth ym = YearMonth.of(year, month);
        LocalDate from = ym.atDay(1), to = ym.atEndOfMonth();
        List<Map<String, Object>> out = new ArrayList<>();
        for (Budget b : repo.findByUserIdAndMonthAndYear(user.getId(), month, year)) {
            BigDecimal spent = "ALL".equals(b.getCategory())
                    ? expenses.total(user.getId(), from, to)
                    : expenses.totalByCategory(user.getId(), b.getCategory(), from, to);
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", b.getId());
            m.put("category", b.getCategory());
            m.put("limitAmount", b.getLimitAmount());
            m.put("spent", spent);
            m.put("remaining", b.getLimitAmount().subtract(spent));
            m.put("percent", FinanceMath.percent(spent, b.getLimitAmount()));
            out.add(m);
        }
        out.sort(Comparator.comparing((Map<String, Object> m) -> !"ALL".equals(m.get("category")))
                .thenComparing(m -> (String) m.get("category")));
        return out;
    }

    /** Create or update (one budget per category per month). */
    @PostMapping
    public Budget save(@Valid @RequestBody Budget body) {
        User user = currentUser.get();
        Budget b = repo.findByUserIdAndCategoryAndMonthAndYear(user.getId(), body.getCategory(), body.getMonth(), body.getYear())
                .orElseGet(Budget::new);
        b.setUser(user);
        b.setCategory(body.getCategory());
        b.setMonth(body.getMonth());
        b.setYear(body.getYear());
        b.setLimitAmount(body.getLimitAmount());
        Budget saved = repo.save(b);
        notifications.checkBudgets(user, saved.getCategory(), LocalDate.of(saved.getYear(), saved.getMonth(), 1));
        return saved;
    }

    @DeleteMapping("/{id}")
    public Map<String, String> delete(@PathVariable Long id) {
        Budget b = repo.findByIdAndUserId(id, currentUser.get().getId()).orElseThrow(NoSuchElementException::new);
        repo.delete(b);
        return Map.of("message", "Budget removed");
    }

    /** Advanced: copy last month's budgets into the selected month (skips ones that already exist). */
    @PostMapping("/copy-previous")
    public Map<String, Object> copyPrevious(@RequestParam int month, @RequestParam int year) {
        User user = currentUser.get();
        YearMonth target = YearMonth.of(year, month);
        YearMonth prev = target.minusMonths(1);
        int copied = 0;
        for (Budget old : repo.findByUserIdAndMonthAndYear(user.getId(), prev.getMonthValue(), prev.getYear())) {
            if (repo.findByUserIdAndCategoryAndMonthAndYear(user.getId(), old.getCategory(), month, year).isPresent()) continue;
            Budget b = new Budget();
            b.setUser(user);
            b.setCategory(old.getCategory());
            b.setLimitAmount(old.getLimitAmount());
            b.setMonth(month);
            b.setYear(year);
            repo.save(b);
            copied++;
        }
        return Map.of("copied", copied, "message", copied + " budget(s) copied from " + prev.getMonth() + " " + prev.getYear());
    }
}
