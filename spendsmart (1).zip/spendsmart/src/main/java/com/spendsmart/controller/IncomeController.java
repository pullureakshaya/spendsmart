package com.spendsmart.controller;

import com.spendsmart.entity.Income;
import com.spendsmart.repository.IncomeRepository;
import com.spendsmart.security.CurrentUser;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/income")
public class IncomeController {
    private final IncomeRepository repo;
    private final CurrentUser currentUser;

    public IncomeController(IncomeRepository repo, CurrentUser currentUser) {
        this.repo = repo;
        this.currentUser = currentUser;
    }

    @GetMapping
    public List<Income> list(@RequestParam(defaultValue = "") String category,
                             @RequestParam(defaultValue = "") String q,
                             @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
                             @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        return repo.search(currentUser.get().getId(), category.trim(),
                from == null ? LocalDate.of(1900, 1, 1) : from,
                to == null ? LocalDate.of(2999, 12, 31) : to, q.trim());
    }

    @PostMapping
    public Income create(@Valid @RequestBody Income body) {
        body.setId(null);
        body.setUser(currentUser.get());
        return repo.save(body);
    }

    @PutMapping("/{id}")
    public Income update(@PathVariable Long id, @Valid @RequestBody Income body) {
        Income i = repo.findByIdAndUserId(id, currentUser.get().getId()).orElseThrow(NoSuchElementException::new);
        i.setAmount(body.getAmount());
        i.setCategory(body.getCategory());
        i.setIncomeDate(body.getIncomeDate());
        i.setDescription(body.getDescription());
        return repo.save(i);
    }

    @DeleteMapping("/{id}")
    public Map<String, String> delete(@PathVariable Long id) {
        Income i = repo.findByIdAndUserId(id, currentUser.get().getId()).orElseThrow(NoSuchElementException::new);
        repo.delete(i);
        return Map.of("message", "Income deleted");
    }
}
