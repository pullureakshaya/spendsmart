/* Generic add / edit / delete / search / filter page used by Expenses and Income */
(async function () {
  const C = window.TXN_CONFIG;
  await SS.init(C.page, C.title);
  const root = document.getElementById('txn-root');
  const money = n => SS.money(n);

  root.innerHTML = `
    <div class="card-ss mb-3">
      <div class="row g-2 align-items-end">
        <div class="col-12 col-md-3"><label class="form-label">Search</label>
          <input id="fQ" class="form-control" placeholder="Search description"></div>
        <div class="col-6 col-md-2"><label class="form-label">${C.catLabel}</label>
          <select id="fCat" class="form-select">${SS.options(C.cats, '', 'All')}</select></div>
        <div class="col-6 col-md-2"><label class="form-label">From</label><input id="fFrom" type="date" class="form-control"></div>
        <div class="col-6 col-md-2"><label class="form-label">To</label><input id="fTo" type="date" class="form-control"></div>
        <div class="col-6 col-md-3 d-flex gap-2">
          <button class="btn btn-outline-ss flex-fill" id="fReset">Reset</button>
          <button class="btn btn-brand flex-fill" id="addBtn"><i class="bi bi-plus-lg"></i> ${C.addLabel}</button>
        </div>
      </div>
    </div>
    <div class="card-ss">
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <div><span class="fw-bold fs-5 num" id="total">${money(0)}</span> <span class="text-muted" id="count"></span></div>
        <div class="btn-group">
          <button class="btn btn-outline-ss btn-sm" data-quick="month">This month</button>
          <button class="btn btn-outline-ss btn-sm" data-quick="year">This year</button>
          <button class="btn btn-outline-ss btn-sm" id="exportBtn"><i class="bi bi-download"></i> Export CSV</button>
        </div>
      </div>
      <div class="table-responsive"><table class="table table-hover">
        <thead><tr><th>${C.catLabel}</th><th>Description</th>${C.payment ? '<th>Payment</th>' : ''}<th>Date</th><th class="text-end">Amount</th><th></th></tr></thead>
        <tbody id="rows"></tbody></table></div>
    </div>

    <div class="modal fade" id="txnModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><form class="modal-content" id="txnForm" novalidate>
      <div class="modal-header"><h5 class="modal-title" id="modalTitle"></h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
      <div class="modal-body">
        <div class="alert alert-danger d-none" id="formErr"></div>
        <input type="hidden" id="id">
        <div class="row g-3">
          <div class="col-6"><label class="form-label">Amount</label><input id="amount" type="number" step="0.01" min="0.01" class="form-control" required>
            <div class="invalid-feedback">Enter an amount greater than zero</div></div>
          <div class="col-6"><label class="form-label">Date</label><input id="date" type="date" class="form-control" required>
            <div class="invalid-feedback">Pick a date</div></div>
          <div class="col-6"><label class="form-label">${C.catLabel}</label><select id="category" class="form-select" required>${SS.options(C.cats)}</select></div>
          ${C.payment ? `<div class="col-6"><label class="form-label">Payment method</label><select id="payment" class="form-select">${SS.options(SS.payMethods)}</select></div>` : ''}
          <div class="col-12"><label class="form-label">Description</label><input id="desc" maxlength="255" class="form-control" placeholder="Optional note"></div>
        </div>
      </div>
      <div class="modal-footer"><button type="button" class="btn btn-outline-ss" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-brand" type="submit">Save</button></div>
    </form></div></div>`;

  const $ = id => document.getElementById(id);
  const modal = new bootstrap.Modal($('txnModal'));
  let items = [];

  const params = () => {
    const p = new URLSearchParams();
    if ($('fQ').value.trim()) p.set('q', $('fQ').value.trim());
    if ($('fCat').value) p.set('category', $('fCat').value);
    if ($('fFrom').value) p.set('from', $('fFrom').value);
    if ($('fTo').value) p.set('to', $('fTo').value);
    return p;
  };

  async function load() {
    try { items = await SS.get(C.endpoint + '?' + params()); render(); } catch (e) { SS.error(e); }
  }

  function render() {
    const sum = items.reduce((s, x) => s + Number(x.amount), 0);
    $('total').textContent = money(sum);
    $('count').textContent = `· ${items.length} record${items.length === 1 ? '' : 's'}`;
    $('rows').innerHTML = items.length ? items.map(x => `
      <tr>
        <td><div class="d-flex align-items-center gap-2">${SS.catIcon(x.category)}<span class="fw-semibold">${SS.esc(x.category)}</span></div></td>
        <td>${SS.esc(x.description) || '<span class="text-muted">—</span>'}</td>
        ${C.payment ? `<td><span class="pill pill-cat">${SS.esc(x.paymentMethod)}</span></td>` : ''}
        <td class="text-nowrap">${SS.date(x[C.dateKey])}</td>
        <td class="text-end fw-bold num ${C.kind === 'income' ? 'pos' : ''}">${C.kind === 'income' ? '+' : '-'}${money(x.amount)}</td>
        <td class="text-end text-nowrap">
          <button class="btn btn-sm btn-outline-ss" data-edit="${x.id}" aria-label="Edit"><i class="bi bi-pencil"></i></button>
          <button class="btn btn-sm btn-outline-ss text-danger" data-del="${x.id}" aria-label="Delete"><i class="bi bi-trash"></i></button>
        </td></tr>`).join('')
      : `<tr><td colspan="6"><div class="empty"><i class="bi bi-inbox"></i>No ${C.kind} records match. Add one to get started.</div></td></tr>`;
  }

  function openForm(x) {
    $('formErr').classList.add('d-none');
    $('txnForm').classList.remove('was-validated');
    $('modalTitle').textContent = x ? 'Edit ' + C.kind : C.addLabel;
    $('id').value = x ? x.id : '';
    $('amount').value = x ? x.amount : '';
    $('date').value = x ? x[C.dateKey] : SS.today();
    $('category').value = x ? x.category : C.cats[0];
    if (C.payment) $('payment').value = x ? x.paymentMethod : 'UPI';
    $('desc').value = x ? (x.description || '') : '';
    modal.show();
  }

  $('addBtn').onclick = () => openForm(null);
  $('rows').onclick = async e => {
    const edit = e.target.closest('[data-edit]'), del = e.target.closest('[data-del]');
    if (edit) openForm(items.find(i => i.id == edit.dataset.edit));
    if (del && await SS.confirm('Delete this ' + C.kind + ' record?')) {
      try { const r = await SS.del(C.endpoint + '/' + del.dataset.del); SS.toast(r.message); load(); SS.loadNotifications(); } catch (err) { SS.error(err); }
    }
  };

  $('txnForm').onsubmit = async e => {
    e.preventDefault();
    const form = e.target;
    form.classList.add('was-validated');
    if (!form.checkValidity() || Number($('amount').value) <= 0) { $('formErr').textContent = 'Please correct the highlighted fields.'; $('formErr').classList.remove('d-none'); return; }
    const body = { amount: Number($('amount').value), category: $('category').value, description: $('desc').value.trim() };
    body[C.dateKey] = $('date').value;
    if (C.payment) body.paymentMethod = $('payment').value;
    const id = $('id').value;
    try {
      await (id ? SS.put(C.endpoint + '/' + id, body) : SS.post(C.endpoint, body));
      modal.hide();
      SS.toast(id ? 'Changes saved' : C.kind === 'income' ? 'Income added' : 'Expense added');
      load(); SS.loadNotifications();
    } catch (err) { $('formErr').textContent = err.message; $('formErr').classList.remove('d-none'); }
  };

  let timer;
  $('fQ').oninput = () => { clearTimeout(timer); timer = setTimeout(load, 300); };
  ['fCat', 'fFrom', 'fTo'].forEach(id => $(id).onchange = load);
  $('fReset').onclick = () => { ['fQ', 'fCat', 'fFrom', 'fTo'].forEach(id => $(id).value = ''); load(); };
  document.querySelectorAll('[data-quick]').forEach(b => b.onclick = () => {
    const now = new Date(), y = now.getFullYear(), m = String(now.getMonth() + 1).padStart(2, '0');
    if (b.dataset.quick === 'month') { $('fFrom').value = `${y}-${m}-01`; $('fTo').value = `${y}-${m}-${new Date(y, now.getMonth() + 1, 0).getDate()}`; }
    else { $('fFrom').value = `${y}-01-01`; $('fTo').value = `${y}-12-31`; }
    load();
  });
  $('exportBtn').onclick = () => { const p = params(); p.set('type', C.kind); location.href = '/api/export/transactions.csv?' + p; };

  load();
})();
