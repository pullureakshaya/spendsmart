(async function () {
  const user = await SS.init('dashboard', 'Dashboard');
  if (!user) return;
  const $ = id => document.getElementById(id);
  $('hello').textContent = 'Welcome back, ' + user.fullName.split(' ')[0];
  $('month').value = SS.thisMonth();
  let pie, bar;

  async function load() {
    const { year, month } = SS.ym($('month').value || SS.thisMonth());
    try {
      const [d, n, monthly] = await Promise.all([
        SS.get(`/api/dashboard?year=${year}&month=${month}`), SS.get('/api/notifications'), SS.get('/api/analytics/monthly?year=' + year)]);
      cards(d); alerts(n.items, d); insights(d); charts(d, monthly, year); recent(d);
    } catch (e) { SS.error(e); }
  }

  function cards(d) {
    const over = d.budget > 0 && d.budgetPercent > 100, pct = Math.min(100, d.budgetPercent);
    const c = (icon, tone, label, val, extra = '') => `<div class="col-6 col-xl"><div class="card-ss h-100"><div class="stat">
      <div class="ico ico-${tone}"><i class="bi ${icon}"></i></div><div><div class="lbl">${label}</div><div class="val num">${val}</div></div></div>${extra}</div></div>`;
    $('cards').innerHTML =
      c('bi-arrow-down-left-circle', 'green', 'Income', SS.moneyShort(d.income)) +
      c('bi-arrow-up-right-circle', 'red', 'Expenses', SS.moneyShort(d.expense)) +
      c('bi-wallet2', 'navy', 'Remaining balance', `<span class="${d.balance < 0 ? 'neg' : ''}">${SS.moneyShort(d.balance)}</span>`) +
      c('bi-bullseye', over ? 'red' : d.budgetPercent >= 80 ? 'amber' : 'amber', 'Monthly budget', d.budget > 0 ? SS.moneyShort(d.budget) : 'Not set',
        d.budget > 0 ? `<div class="progress mt-3"><div class="progress-bar ${SS.barClass(d.budgetPercent)}" style="width:${pct}%"></div></div>
          <small class="${over ? 'neg' : 'text-muted'} fw-semibold">${over ? 'Over by ' + SS.moneyShort(-d.budgetRemaining) : d.budgetPercent.toFixed(0) + '% used · ' + SS.moneyShort(d.budgetRemaining) + ' left'}</small>`
          : '<a class="small fw-semibold" href="/budgets.html">Set a budget</a>') +
      c('bi-piggy-bank', 'green', 'Savings', `<span class="${d.savings < 0 ? 'neg' : ''}">${SS.moneyShort(d.savings)}</span>`,
        `<small class="text-muted">${d.savingsRate.toFixed(0)}% of income · ${SS.moneyShort(d.totalGoalSavings)} in goals</small>`);
  }

  function alerts(items, d) {
    const unread = items.filter(n => !n.seen && (n.type === 'DANGER' || n.type === 'WARNING')).slice(0, 3);
    $('alerts').innerHTML = unread.map(n => `<div class="alert-ss ${n.type}"><i class="bi ${n.type === 'DANGER' ? 'bi-exclamation-octagon-fill' : 'bi-exclamation-triangle-fill'}"></i><div>${SS.esc(n.message)}</div></div>`).join('');
  }

  function insights(d) {
    const col = { good: 'pos', warn: 'text-warning', info: 'text-muted' }, ic = { good: 'bi-check-circle', warn: 'bi-exclamation-triangle', info: 'bi-lightbulb' };
    $('insights').innerHTML = d.insights.length ? d.insights.map(i => `<div class="insight"><i class="bi ${ic[i.type]} ${col[i.type]}"></i><div>${SS.esc(i.text)}</div></div>`).join('')
      : '<div class="empty">Add a few transactions to see insights.</div>';
    $('score').textContent = d.healthScore;
    $('scoreLabel').textContent = d.healthLabel;
    const ring = $('ring');
    ring.style.setProperty('--p', d.healthScore);
    ring.style.setProperty('--c', d.healthScore >= 60 ? 'var(--green)' : d.healthScore >= 40 ? 'var(--amber)' : 'var(--red)');
  }

  function charts(d, m, year) {
    pie && pie.destroy(); bar && bar.destroy();
    const palette = d.categories.map(c => (SS.catStyle[c.category] || SS.catStyle.Others)[1]);
    if (d.categories.length) {
      pie = new Chart($('pie'), { type: 'doughnut', data: { labels: d.categories.map(c => c.category),
        datasets: [{ data: d.categories.map(c => c.total), backgroundColor: palette, borderWidth: 0 }] },
        options: { maintainAspectRatio: false, cutout: '62%', plugins: { legend: { position: 'bottom' }, tooltip: { callbacks: { label: c => ` ${c.label}: ${SS.moneyShort(c.raw)}` } } } } });
    } else $('pie').parentElement.innerHTML = '<div class="empty"><i class="bi bi-pie-chart"></i>No expenses this month</div>';
    $('yearLbl').textContent = year;
    bar = new Chart($('bar'), { type: 'bar', data: { labels: m.labels, datasets: [
      { label: 'Income', data: m.income, backgroundColor: '#14a35c', borderRadius: 5 },
      { label: 'Expenses', data: m.expense, backgroundColor: '#0b1f3a', borderRadius: 5 }] },
      options: { maintainAspectRatio: false, plugins: { legend: { position: 'bottom' } }, scales: { y: { ticks: { callback: v => SS.moneyShort(v) } } } } });
  }

  function recent(d) {
    $('recent').innerHTML = d.recent.length ? d.recent.map(t => `<tr>
      <td style="width:50px">${SS.catIcon(t.category)}</td>
      <td><div class="fw-semibold">${SS.esc(t.title)}</div><small class="text-muted">${SS.esc(t.category)}</small></td>
      <td class="text-muted text-nowrap">${SS.date(t.date)}</td>
      <td class="text-end fw-bold num ${t.type === 'INCOME' ? 'pos' : ''}">${t.type === 'INCOME' ? '+' : '-'}${SS.money(t.amount)}</td></tr>`).join('')
      : '<tr><td><div class="empty"><i class="bi bi-inbox"></i>No transactions yet</div></td></tr>';
  }

  $('month').onchange = load;
  load();
})();
