/* SpendSmart – shared helpers: API calls, layout shell, toasts, formatting */
(function () {
  const saved = localStorage.getItem('ss-theme');
  if (saved) document.documentElement.setAttribute('data-theme', saved);
})();

const SS = {
  expenseCats: ['Food', 'Shopping', 'Transportation', 'Education', 'Entertainment', 'Healthcare', 'Bills', 'Others'],
  incomeCats: ['Salary', 'Freelance', 'Business', 'Investments', 'Gift', 'Others'],
  payMethods: ['Cash', 'UPI', 'Credit Card', 'Debit Card', 'Net Banking'],
  catStyle: {
    Food: ['bi-egg-fried', '#f59e0b'], Shopping: ['bi-bag', '#8b5cf6'], Transportation: ['bi-bus-front', '#0ea5e9'],
    Education: ['bi-book', '#14b8a6'], Entertainment: ['bi-controller', '#ec4899'], Healthcare: ['bi-heart-pulse', '#ef4444'],
    Bills: ['bi-receipt', '#6366f1'], Others: ['bi-three-dots', '#64748b'], Salary: ['bi-briefcase', '#16a34a'],
    Freelance: ['bi-laptop', '#0ea5e9'], Business: ['bi-shop', '#f59e0b'], Investments: ['bi-graph-up-arrow', '#8b5cf6'],
    Gift: ['bi-gift', '#ec4899'], ALL: ['bi-wallet2', '#0b1f3a']
  },
  user: null,

  /* ---------- API ---------- */
  async api(method, url, body) {
    const res = await fetch(url, {
      method, credentials: 'same-origin',
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : {},
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
    if (res.status === 401) { location.href = '/login.html'; throw new Error('Please log in'); }
    const isJson = (res.headers.get('content-type') || '').includes('json');
    const data = isJson ? await res.json() : null;
    if (!res.ok) throw new Error((data && data.message) || 'Something went wrong. Please try again.');
    return data;
  },
  get(url) { return this.api('GET', url); },
  post(url, body) { return this.api('POST', url, body === undefined ? {} : body); },
  put(url, body) { return this.api('PUT', url, body === undefined ? {} : body); },
  del(url) { return this.api('DELETE', url); },

  /* ---------- Formatting ---------- */
  money(n) {
    const sym = { INR: '₹', USD: '$', EUR: '€', GBP: '£' }[(this.user && this.user.currency) || 'INR'] || '₹';
    const v = Number(n || 0);
    return (v < 0 ? '-' : '') + sym + Math.abs(v).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  },
  moneyShort(n) {
    const sym = { INR: '₹', USD: '$', EUR: '€', GBP: '£' }[(this.user && this.user.currency) || 'INR'] || '₹';
    return (Number(n) < 0 ? '-' : '') + sym + Math.abs(Number(n || 0)).toLocaleString('en-IN', { maximumFractionDigits: 0 });
  },
  date(d) { return d ? new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'; },
  esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); },
  today() { return new Date().toISOString().slice(0, 10); },
  thisMonth() { return new Date().toISOString().slice(0, 7); },
  barClass(p) { return p > 100 ? 'bar-over' : p >= 80 ? 'bar-warn' : 'bar-ok'; },
  catIcon(cat, size) {
    const [icon, color] = this.catStyle[cat] || this.catStyle.Others;
    return `<span class="cat-ico" style="background:${color}22;color:${color}"><i class="bi ${icon}"></i></span>`;
  },
  options(list, selected, all) {
    return (all ? `<option value="">${all}</option>` : '') + list.map(c => `<option ${c === selected ? 'selected' : ''}>${c}</option>`).join('');
  },
  timeAgo(iso) {
    const s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (s < 60) return 'just now';
    if (s < 3600) return Math.floor(s / 60) + ' min ago';
    if (s < 86400) return Math.floor(s / 3600) + ' h ago';
    return Math.floor(s / 86400) + ' d ago';
  },

  /* ---------- Toast & confirm ---------- */
  toast(msg, type = 'ok') {
    let wrap = document.querySelector('.toast-wrap');
    if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toast-wrap'; wrap.setAttribute('role', 'status'); document.body.appendChild(wrap); }
    const t = document.createElement('div');
    t.className = 'toast-ss ' + type;
    t.innerHTML = `<i class="bi ${type === 'error' ? 'bi-exclamation-octagon' : 'bi-check-circle-fill'}"></i><span>${this.esc(msg)}</span>`;
    wrap.appendChild(t);
    setTimeout(() => t.remove(), 4200);
  },
  error(e) { this.toast(e.message || String(e), 'error'); },
  confirm(message, okLabel = 'Delete') {
    return new Promise(resolve => {
      const el = document.createElement('div');
      el.className = 'modal fade';
      el.innerHTML = `<div class="modal-dialog modal-dialog-centered modal-sm"><div class="modal-content">
        <div class="modal-body pt-4 text-center"><i class="bi bi-exclamation-triangle fs-1 text-warning"></i>
        <p class="mt-2 mb-0 fw-semibold">${this.esc(message)}</p></div>
        <div class="modal-footer border-0 justify-content-center">
        <button class="btn btn-outline-ss" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-danger" id="ok">${okLabel}</button></div></div></div>`;
      document.body.appendChild(el);
      const m = new bootstrap.Modal(el);
      let answer = false;
      el.querySelector('#ok').onclick = () => { answer = true; m.hide(); };
      el.addEventListener('hidden.bs.modal', () => { el.remove(); resolve(answer); });
      m.show();
    });
  },

  /* ---------- Layout shell ---------- */
  nav: [
    ['dashboard', 'Dashboard', 'bi-grid-1x2'], ['expenses', 'Expenses', 'bi-credit-card-2-front'], ['income', 'Income', 'bi-cash-coin'],
    ['budgets', 'Budgets', 'bi-pie-chart'], ['analytics', 'Analytics', 'bi-bar-chart-line'], ['savings', 'Savings goals', 'bi-piggy-bank'],
    ['recurring', 'Recurring', 'bi-arrow-repeat'], ['profile', 'Profile', 'bi-person-gear']
  ],

  async init(page, title) {
    try { this.user = await this.get('/api/auth/me'); } catch (e) { return null; }
    const content = document.getElementById('page');
    const theme = document.documentElement.getAttribute('data-theme') === 'dark';
    const shell = document.createElement('div');
    shell.innerHTML = `
      <aside class="sidebar" id="sidebar">
        <a class="brand" href="/dashboard.html"><span class="brand-mark"><i class="bi bi-wallet2"></i></span>SpendSmart</a>
        <nav class="nav flex-column gap-1">
          ${this.nav.map(n => `<a class="nav-link ${n[0] === page ? 'active' : ''}" href="/${n[0]}.html"><i class="bi ${n[2]}"></i>${n[1]}</a>`).join('')}
        </nav>
        <button class="nav-link logout" id="logoutBtn"><i class="bi bi-box-arrow-left"></i>Log out</button>
      </aside>
      <div class="backdrop" id="backdrop"></div>
      <div class="main">
        <header class="topbar">
          <button class="icon-btn d-lg-none" id="menuBtn" aria-label="Open menu"><i class="bi bi-list fs-5"></i></button>
          <h1 class="flex-grow-1">${title}</h1>
          <button class="icon-btn" id="themeBtn" aria-label="Toggle dark mode"><i class="bi ${theme ? 'bi-sun' : 'bi-moon-stars'}"></i></button>
          <div class="position-relative">
            <button class="icon-btn" id="bellBtn" aria-label="Notifications"><i class="bi bi-bell"></i><span class="badge-dot d-none" id="bellCount">0</span></button>
            <div class="notif-panel" id="notifPanel">
              <div class="d-flex justify-content-between align-items-center p-3 border-bottom">
                <b>Notifications</b>
                <span><button class="btn btn-sm btn-link p-0 me-2" id="readAll">Mark all read</button><button class="btn btn-sm btn-link text-danger p-0" id="clearAll">Clear</button></span>
              </div>
              <div class="notif-list" id="notifList"></div>
            </div>
          </div>
          <a href="/profile.html" class="avatar text-decoration-none" title="${this.esc(this.user.fullName)}">${this.esc(this.user.fullName.trim()[0].toUpperCase())}</a>
        </header>
        <main class="content" id="contentHost"></main>
      </div>`;
    document.body.prepend(...shell.childNodes);
    document.getElementById('contentHost').appendChild(content);
    content.classList.remove('d-none');

    const sidebar = document.getElementById('sidebar'), backdrop = document.getElementById('backdrop');
    const toggle = open => { sidebar.classList.toggle('open', open); backdrop.classList.toggle('show', open); };
    document.getElementById('menuBtn').onclick = () => toggle(true);
    backdrop.onclick = () => toggle(false);
    document.getElementById('logoutBtn').onclick = async () => { await fetch('/api/auth/logout', { method: 'POST' }); location.href = '/login.html'; };
    document.getElementById('themeBtn').onclick = () => {
      const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      localStorage.setItem('ss-theme', next); location.reload();
    };

    const panel = document.getElementById('notifPanel');
    document.getElementById('bellBtn').onclick = e => { e.stopPropagation(); panel.classList.toggle('show'); };
    document.addEventListener('click', e => { if (!panel.contains(e.target)) panel.classList.remove('show'); });
    document.getElementById('readAll').onclick = async () => { await this.put('/api/notifications/read-all'); this.loadNotifications(); };
    document.getElementById('clearAll').onclick = async () => { await this.del('/api/notifications'); this.loadNotifications(); };
    this.loadNotifications();

    if (window.Chart) {
      Chart.defaults.font.family = "'Manrope', sans-serif";
      Chart.defaults.color = theme ? '#93a4bd' : '#64748b';
      Chart.defaults.borderColor = theme ? '#1f3a63' : '#e2e8f0';
    }
    return this.user;
  },

  async loadNotifications() {
    try {
      const data = await this.get('/api/notifications');
      const badge = document.getElementById('bellCount');
      badge.textContent = data.unread > 9 ? '9+' : data.unread;
      badge.classList.toggle('d-none', data.unread === 0);
      const list = document.getElementById('notifList');
      list.innerHTML = data.items.length ? data.items.map(n => `
        <div class="notif-item ${n.seen ? '' : 'unread'}"><span class="dot ${n.type}"></span>
        <div><div>${this.esc(n.message)}</div><small class="text-muted">${this.timeAgo(n.createdAt)}</small></div></div>`).join('')
        : '<div class="empty"><i class="bi bi-bell-slash"></i>You are all caught up</div>';
      this.notifications = data.items;
    } catch (e) { /* ignore */ }
  },

  /** Month input helper: returns {year, month} from "YYYY-MM" */
  ym(value) { const [y, m] = value.split('-').map(Number); return { year: y, month: m }; }
};
