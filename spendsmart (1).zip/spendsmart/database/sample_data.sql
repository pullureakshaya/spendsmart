-- Optional: tiny hand-written sample (the app already seeds richer demo data on first run).
-- Run this only on an EMPTY database after the tables exist, and set spendsmart.seed-demo=false.
USE spendsmart;
INSERT INTO users (full_name, email, password, phone, currency) VALUES
 ('Demo User', 'demo@spendsmart.com', '$2a$10$NfMUnIMEQYCj/1iLG3Aa7uJxLdTfoied9ImsiH41yRA95mJP5wqDS', '9876543210', 'INR');   -- password: Demo@123
SET @u = LAST_INSERT_ID();
INSERT INTO income (user_id, amount, category, income_date, description) VALUES
 (@u, 55000, 'Salary', DATE_FORMAT(CURDATE(), '%Y-%m-01'), 'Monthly salary'),
 (@u, 6000, 'Freelance', DATE_FORMAT(CURDATE(), '%Y-%m-02'), 'Website project');
INSERT INTO expenses (user_id, amount, category, expense_date, description, payment_method) VALUES
 (@u, 12000, 'Bills', DATE_FORMAT(CURDATE(), '%Y-%m-01'), 'House rent', 'Net Banking'),
 (@u, 650, 'Food', DATE_FORMAT(CURDATE(), '%Y-%m-01'), 'Groceries', 'UPI'),
 (@u, 2400, 'Shopping', DATE_FORMAT(CURDATE(), '%Y-%m-01'), 'Festival shopping', 'Credit Card'),
 (@u, 300, 'Transportation', DATE_FORMAT(CURDATE(), '%Y-%m-01'), 'Cab', 'UPI');
INSERT INTO budgets (user_id, category, limit_amount, month, year) VALUES
 (@u, 'ALL', 32000, MONTH(CURDATE()), YEAR(CURDATE())),
 (@u, 'Shopping', 2500, MONTH(CURDATE()), YEAR(CURDATE())),
 (@u, 'Food', 4000, MONTH(CURDATE()), YEAR(CURDATE()));
INSERT INTO savings_goals (user_id, name, target_amount, saved_amount, deadline) VALUES
 (@u, 'Emergency fund', 100000, 35000, DATE_ADD(CURDATE(), INTERVAL 10 MONTH));
