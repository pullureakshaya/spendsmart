-- Reference schema (regenerated from the JPA entities).
-- Hibernate (ddl-auto=update) creates these tables automatically, so running this file is OPTIONAL.
CREATE DATABASE IF NOT EXISTS spendsmart;
USE spendsmart;

CREATE TABLE users (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,              -- BCrypt hash
  phone VARCHAR(20),
  currency VARCHAR(5) NOT NULL DEFAULT 'INR',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE expenses (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  amount DECIMAL(12,2) NOT NULL CHECK (amount > 0),
  category VARCHAR(40) NOT NULL,
  expense_date DATE NOT NULL,
  description VARCHAR(255),
  payment_method VARCHAR(30) DEFAULT 'Cash',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_exp_user_date (user_id, expense_date)
);

CREATE TABLE income (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  amount DECIMAL(12,2) NOT NULL CHECK (amount > 0),
  category VARCHAR(40) NOT NULL,
  income_date DATE NOT NULL,
  description VARCHAR(255),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_inc_user_date (user_id, income_date)
);

CREATE TABLE budgets (                          -- category 'ALL' = overall monthly budget
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  category VARCHAR(40) NOT NULL,
  limit_amount DECIMAL(12,2) NOT NULL CHECK (limit_amount > 0),
  month INT NOT NULL,
  year INT NOT NULL,
  UNIQUE KEY uq_budget (user_id, category, month, year),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE savings_goals (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  name VARCHAR(80) NOT NULL,
  target_amount DECIMAL(12,2) NOT NULL,
  saved_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  deadline DATE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE notifications (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  message VARCHAR(400) NOT NULL,
  type VARCHAR(20) NOT NULL DEFAULT 'INFO',     -- INFO / WARNING / DANGER / SUCCESS
  seen BOOLEAN NOT NULL DEFAULT FALSE,
  alert_key VARCHAR(120),                       -- prevents duplicate alerts
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notif_user (user_id, seen)
);

CREATE TABLE recurring_transactions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  type VARCHAR(10) NOT NULL,                    -- EXPENSE / INCOME
  amount DECIMAL(12,2) NOT NULL,
  category VARCHAR(40) NOT NULL,
  description VARCHAR(255),
  payment_method VARCHAR(30) DEFAULT 'Cash',
  frequency VARCHAR(10) NOT NULL,
  next_date DATE NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
