# SpendSmart - Project Summary

## Advanced features included
- Recurring transactions (daily / weekly / monthly / yearly) that post automatically
- Financial health score (0-100) on the dashboard
- Smart insights: biggest category, month-over-month change, month-end forecast, safe daily spend
- Notification centre with unread badge, mark all read and clear
- Savings goals with contributions, withdrawals and a "save X per month" suggestion
- One-click "copy last month's budgets"
- CSV export of filtered transactions
- Dark mode, printable reports, multi-currency display
- Demo data seeder (four months of sample data)

## Run it
1. Install JDK 17+, Maven, MySQL 8 and the VS Code extensions it suggests.
2. Set `spring.datasource.username` and `spring.datasource.password` in `src/main/resources/application.properties`.
3. Run `mvn spring-boot:run` (or use the Spring Boot Dashboard), then open http://localhost:8080
4. Log in with `demo@spendsmart.com` / `Demo@123`

## Status
Not compiled or run in the environment where it was written (no Maven access). If the first start
fails, check the console error first; likely spots are the repository queries and the security setup.

## Folder layout
- `src/main/java/com/spendsmart/` config, controller, entity, repository, security, service, util
- `src/main/resources/static/` HTML pages, css, js
- `database/` schema.sql, sample_data.sql
- `docs/` this summary and VIVA_AND_DEMO.md
- `README.md` setup, API list, testing, troubleshooting
