# SpendSmart – Demo Script and Viva Questions

## 5-minute demo script
1. **Home page** – explain the problem: people do not know where money goes.
2. **Register** a new user, show validation errors, then log in (also mention the demo account).
3. **Dashboard** – income, expenses, balance, budget bar, health score, insights, charts.
4. **Add an expense** that pushes a category past 80% – show the alert banner and the bell badge.
5. **Budgets** – overall and category limits, colour changes, "copy last month".
6. **Expenses** – search, filters, edit, delete, export CSV.
7. **Analytics** – pie, bar, line, switch month to whole year, print report.
8. **Savings goals** – add money, see the "save X per month" tip.
9. **Recurring** – add a rule dated yesterday, click "Post due items now".
10. **Security** – log out, try opening `/dashboard.html` (redirects). Show the BCrypt hash in MySQL.

## Viva questions with short answers

**Architecture**
1. *Explain the architecture.* Three layers: static front end calls REST controllers; controllers use repositories (Spring Data JPA) which talk to MySQL. Spring Security guards every request.
2. *Why Spring Boot?* Auto-configuration, embedded Tomcat, starters, and quick REST development.
3. *What is JPA / Hibernate?* JPA is the Java persistence specification; Hibernate implements it and maps entity classes to tables so we write little SQL.
4. *What does `ddl-auto=update` do?* Hibernate creates or alters tables to match entities at start-up.
5. *Why DECIMAL / BigDecimal for money?* Floating point cannot represent decimals exactly; BigDecimal avoids rounding errors.
6. *What is the difference between `@OneToMany` and `@ManyToOne`, and which do you use?* Each record has a `@ManyToOne` to its user (many expenses per user). Lazy loading avoids loading the user each time.

**Security**
7. *How are passwords stored?* BCrypt hash with a random salt, never plain text.
8. *How does login work?* The login endpoint authenticates with `AuthenticationManager`, stores the security context in the HTTP session, and the browser sends the session cookie on every request.
9. *How do you stop a user seeing another user's data?* Every repository call includes the logged-in user's id (`findByIdAndUserId`); other users' ids return 404.
10. *What is CSRF and why disabled here?* CSRF tricks a logged-in browser into sending unwanted requests. Disabled to keep the demo simple; production should enable it with tokens.
11. *What is SQL injection and how are you protected?* Injecting SQL through input. JPA uses parameterised queries, so inputs are never concatenated into SQL.
12. *Where is validation done?* Browser (HTML5 and JS) for quick feedback, server (Bean Validation annotations like `@DecimalMin`) for security.

**Features**
13. *How do overspending alerts work?* After an expense is saved, `NotificationService` computes spent / limit. At 80%, 100% and above 100% it creates one notification each, using an alert key to avoid duplicates.
14. *How does the recurring feature work?* A `@Scheduled` cron job runs nightly, finds active rules whose next date is due, creates the expense or income and advances the next date.
15. *How is the health score calculated?* 40 points savings rate, 40 points budget discipline, 20 points goal progress (`FinanceMath.healthScore`).
16. *How is the month-end forecast computed?* Spending so far divided by days passed, multiplied by days in the month.
17. *How are charts produced?* REST endpoints return JSON arrays; Chart.js draws pie, bar and line charts from them.
18. *How is the CSV export protected from formula injection?* Cells starting with `=`, `+`, `-` or `@` get a leading apostrophe.

**Database**
19. *Show the ER relationships.* One user has many expenses, income rows, budgets, goals, notifications and recurring rules, all linked by `user_id` foreign keys with cascade delete.
20. *Why a unique key on budgets?* One budget per user, category and month; saving again updates it.

**Improvements**
21. *What would you add next?* JWT for mobile, email alerts, receipt OCR, PDF reports, bank import, AI spending assistant.
22. *Limitations?* Single currency per transaction (display only), CSRF off, no email verification.
