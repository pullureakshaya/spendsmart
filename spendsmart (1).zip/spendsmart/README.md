# SpendSmart – Smart Expense and Budget Manager

A full-stack personal finance app: **Spring Boot 3 + Spring Security + Spring Data JPA + MySQL** on the back end and **HTML / CSS / JavaScript / Bootstrap 5 / Chart.js** on the front end. All data is stored in MySQL and every record belongs to the logged-in user.

## Features

**Core (from the project brief)**
- Registration, login, logout (BCrypt passwords, session-based Spring Security)
- Dashboard: income, expenses, balance, budget, savings, recent transactions, charts
- Expense and income management with search and filters by text, category and date
- Overall and category-wise monthly budgets with colour-coded progress bars
- Smart overspending alerts at 80%, 100% and when exceeded (overall and per category)
- Analytics: pie, bar and line charts, monthly and yearly reports, category analysis
- Savings goals with progress rings, profile and password management

**Advanced additions**
| Feature | Where |
|---|---|
| Recurring transactions that post automatically (daily / weekly / monthly / yearly) | `RecurringService`, Recurring page |
| Financial health score (0-100) | `FinanceMath.healthScore`, Dashboard |
| Smart insights: biggest category, month-over-month change, month-end forecast, safe daily spend | `DashboardController` |
| Notification centre with unread badge, mark all read, clear | bell icon in top bar |
| Savings goal contributions, withdrawals and "save X per month" suggestion | Savings page |
| One-click "copy last month's budgets" | Budgets page |
| CSV export of filtered transactions (formula-injection safe) | `ExportController` |
| Dark mode, printable reports, multi-currency display | top bar, Analytics, Profile |
| Demo data seeder (4 months of data) | `DataSeeder` |

## Folder structure

```
spendsmart/
├── pom.xml
├── README.md
├── database/
│   ├── schema.sql              # reference schema (tables are auto-created by Hibernate)
│   └── sample_data.sql         # optional hand-written sample rows
├── docs/VIVA_AND_DEMO.md       # demo script + viva questions with answers
├── .vscode/                    # recommended extensions, launch config
└── src/
    ├── main/
    │   ├── java/com/spendsmart/
    │   │   ├── SpendSmartApplication.java
    │   │   ├── config/         # SecurityConfig, GlobalExceptionHandler, DataSeeder
    │   │   ├── security/       # CustomUserDetailsService, CurrentUser
    │   │   ├── entity/         # User, Expense, Income, Budget, SavingsGoal, Notification, RecurringTransaction
    │   │   ├── repository/     # Spring Data JPA repositories
    │   │   ├── service/        # NotificationService (alerts), RecurringService (scheduler)
    │   │   ├── controller/     # REST controllers
    │   │   └── util/           # FinanceMath
    │   └── resources/
    │       ├── application.properties
    │       └── static/         # front end: *.html, css/style.css, js/*.js
    └── test/java/com/spendsmart/FinanceMathTest.java
```

## Run in VS Code

1. **Install** JDK 17+, Maven 3.9+ (or use the wrapper later), MySQL 8 and VS Code.
2. In VS Code install the recommended extensions (a prompt appears on opening the folder): *Extension Pack for Java*, *Spring Boot Extension Pack*, *Lombok Annotations Support*.
3. **Start MySQL** and make sure you know the root password. The database `spendsmart` is created automatically.
4. Open `src/main/resources/application.properties` and set `spring.datasource.username` and `spring.datasource.password`.
5. **File > Open Folder** and choose the `spendsmart` folder. Wait for "Java: Ready" in the status bar.
6. Run it using any one of:
   - Open `SpendSmartApplication.java` and click **Run** above `main`, or press **F5**.
   - Spring Boot Dashboard (left sidebar) > spendsmart > Run.
   - Terminal: `mvn spring-boot:run`
7. Open **http://localhost:8080**. Log in with the demo account **demo@spendsmart.com / Demo@123**, or register a new one.

The first start creates the tables and the demo data. Set `spendsmart.seed-demo=false` to skip demo data.

*IntelliJ / Eclipse:* import as an existing Maven project, enable Lombok annotation processing, run `SpendSmartApplication`.

> The pages load Bootstrap, Bootstrap Icons, Chart.js and the Manrope font from a CDN, so an internet connection is needed in the browser.

## REST API (all `/api/**` need a logged-in session except register and login)

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Log in (starts session) |
| POST | `/api/auth/logout` | Log out |
| GET | `/api/auth/me` | Current user |
| GET / PUT | `/api/profile` | View / update profile |
| PUT | `/api/profile/password` | Change password |
| GET | `/api/dashboard?year=&month=` | Cards, insights, health score, recent items |
| GET, POST | `/api/expenses` (`?q=&category=&from=&to=`) | List with filters / add |
| PUT, DELETE | `/api/expenses/{id}` | Edit / delete |
| GET, POST | `/api/income` | List with filters / add |
| PUT, DELETE | `/api/income/{id}` | Edit / delete |
| GET | `/api/budgets?month=&year=` | Budgets with spent, remaining, percent |
| POST | `/api/budgets` | Create or update a budget |
| POST | `/api/budgets/copy-previous?month=&year=` | Copy last month's budgets |
| DELETE | `/api/budgets/{id}` | Remove budget |
| GET, POST | `/api/savings` | Goals / create goal |
| PUT, DELETE | `/api/savings/{id}` | Edit / delete goal |
| POST | `/api/savings/{id}/contribute` | Add (positive) or withdraw (negative) money |
| GET | `/api/analytics/report?year=&month=` | Totals and category breakdown (`month=0` for the year) |
| GET | `/api/analytics/monthly?year=` | 12-month income and expense arrays |
| GET | `/api/analytics/trend?year=&month=` | Daily or monthly spending trend |
| GET, POST | `/api/recurring` | List / create recurring rule |
| PUT, DELETE | `/api/recurring/{id}` | Edit / delete rule |
| POST | `/api/recurring/run-now` | Post all due items immediately |
| GET | `/api/notifications` | Latest alerts and unread count |
| PUT | `/api/notifications/read-all` | Mark all read |
| DELETE | `/api/notifications` | Clear all |
| GET | `/api/export/transactions.csv?type=expense\|income` | Download CSV |

## Testing

**Automated:** `mvn test` runs `FinanceMathTest` (percent, alert thresholds, health score).

**Manual test cases**
| # | Steps | Expected |
|---|---|---|
| 1 | Register with an existing email | Error: email already registered |
| 2 | Register with password `abc` | Validation error (8+ characters, letters and numbers) |
| 3 | Log in with a wrong password | "Incorrect email or password" |
| 4 | Open `/dashboard.html` while logged out | Redirected to login |
| 5 | Add an expense with amount `-50` or `0` | Rejected, nothing saved |
| 6 | Add, edit, delete an expense | List and dashboard totals update |
| 7 | Set Food budget 1000, add Food expenses of 800, then 200, then 50 | Alerts at 80%, 100% and "exceeded" appear once each |
| 8 | Filter expenses by category and date range | Only matching rows; total changes |
| 9 | Export CSV | File downloads, opens in Excel |
| 10 | Add a recurring expense with a past date, click "Post due items now" | Transactions created, next date moves forward |
| 11 | Log in as a second user | Cannot see the first user's data; `/api/expenses/<other id>` returns 404 |
| 12 | Add 500 to a goal, withdraw more than saved | Error on over-withdraw |

**Quick API check (curl):**
```bash
curl -c jar.txt -H "Content-Type: application/json" -d '{"email":"demo@spendsmart.com","password":"Demo@123"}' http://localhost:8080/api/auth/login
curl -b jar.txt "http://localhost:8080/api/dashboard?year=2026&month=11"
```

## Security notes
- Passwords are hashed with BCrypt; sessions are server-side.
- Every query filters by the logged-in user's id, so one user cannot read or change another's records.
- Input is validated on the client and again on the server (Bean Validation).
- CSRF protection is **disabled** to keep the REST + `fetch` demo simple. For production enable it and send the token with each request, and serve over HTTPS.
- Change the default database password before deploying anywhere public.

## Troubleshooting
| Problem | Fix |
|---|---|
| `Access denied for user 'root'` | Fix username/password in `application.properties` |
| `Communications link failure` | MySQL is not running or the port is not 3306 |
| Red errors about `getX()` / `setX()` in VS Code | Install *Lombok Annotations Support*, then run *Java: Clean Java Language Server Workspace* |
| Port 8080 in use | Set `server.port=8081` |
| Charts or icons missing | No internet access (CDN) |

## Ideas for further work
Receipt upload with OCR, email or SMS alerts, bank statement CSV import, an AI assistant that answers questions about your spending, JWT authentication for a mobile app, shared household budgets, PDF report export.
